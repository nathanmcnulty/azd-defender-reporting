// =============================================================================
// INDEXEDDB CACHE
// =============================================================================

const VULNDB_NAME = 'VulnDashboardCache';
const VULNDB_VERSION = 2;
const VULNDB_STORE = 'denormalized';
const DERIVED_CACHE_SCHEMA = 3;
const DIGEST_TIMEOUT_MS = 2000;
const IDB_OPERATION_TIMEOUT_MS = 2000;
const WORKER_OPERATION_TIMEOUT_MS = 10000;
const MAX_IDB_CACHE_ENTRIES = 4;
const MAX_IDB_CACHE_ROWS = 500000;

function bytesToHex(bytes) {
    let output = '';
    for (let index = 0; index < bytes.length; index++) {
        output += bytes[index].toString(16).padStart(2, '0');
    }
    return output;
}

function computeFallbackDigestHex(bytes) {
    let hash = 0xcbf29ce484222325n;
    const prime = 0x100000001b3n;
    for (let index = 0; index < bytes.length; index++) {
        hash ^= BigInt(bytes[index]);
        hash = BigInt.asUintN(64, hash * prime);
    }
    return hash.toString(16).padStart(16, '0');
}

async function computeDigestHex(bytes) {
    const subtle = globalThis.crypto && globalThis.crypto.subtle ? globalThis.crypto.subtle : null;
    if (subtle) {
        try {
            const digest = await Promise.race([
                subtle.digest('SHA-256', bytes),
                new Promise((_, reject) => {
                    setTimeout(() => reject(new Error('SHA-256 digest timed out.')), DIGEST_TIMEOUT_MS);
                })
            ]);
            return bytesToHex(new Uint8Array(digest));
        } catch (error) {
            console.warn('Web Crypto SHA-256 digest failed, using deterministic fallback digest.', error);
        }
    }

    if (typeof require === 'function') {
        try {
            const nodeCrypto = require('crypto');
            return nodeCrypto.createHash('sha256').update(Buffer.from(bytes)).digest('hex');
        } catch (error) {
            console.warn('Node SHA-256 fallback unavailable, using deterministic fallback digest.', error);
        }
    }

    return computeFallbackDigestHex(bytes);
}

function getEmbeddedPayloadFingerprintInput() {
    const lookupsText = getScriptElementText('lookupsData');
    const vulnsText = getScriptElementText('vulnsData');

    if (lookupsText || vulnsText) {
        return `${lookupsText.length}:${lookupsText}\n${vulnsText.length}:${vulnsText}`;
    }

    const fallbackLookups = lookups ? JSON.stringify(lookups) : '';
    const fallbackVulns = rawVulns ? JSON.stringify(rawVulns) : '';
    return `${fallbackLookups.length}:${fallbackLookups}\n${fallbackVulns.length}:${fallbackVulns}`;
}

/**
 * Compute a fingerprint for the embedded dataset using the full payload.
 * @returns {Promise<string>}
 */
async function computeDataFingerprint() {
    const len = getRawVulnCount();
    if (len === 0) return `derived_${DERIVED_CACHE_SCHEMA}_empty`;

    const input = getEmbeddedPayloadFingerprintInput();
    const bytes = new TextEncoder().encode(input);
    const hash = await computeDigestHex(bytes);
    return `derived_${DERIVED_CACHE_SCHEMA}_fp_${len}_${hash}`;
}

/**
 * Compute a fingerprint from raw compressed bytes so we can check the
 * IndexedDB cache *before* decompressing / denormalizing.
 * @param {Uint8Array} bytes
 * @returns {Promise<string>}
 */
async function computeCompressedFingerprint(bytes) {
    const len = bytes.length;
    const hash = await computeDigestHex(bytes);
    return `derived_${DERIVED_CACHE_SCHEMA}_cfp_${len}_${hash}`;
}

/**
 * Open (or create) the IndexedDB cache database.
 * @returns {Promise<IDBDatabase>}
 */
function openVulnDB() {
    if (typeof indexedDB === 'undefined' || !indexedDB || typeof indexedDB.open !== 'function') {
        return Promise.reject(new Error('IndexedDB is unavailable.'));
    }

    return new Promise((resolve, reject) => {
        let settled = false;
        let req = null;
        const timeoutId = setTimeout(() => {
            if (settled) {
                return;
            }

            settled = true;
            try { req?.result?.close(); } catch { /* ignore close failures */ }
            reject(new Error('IndexedDB open timed out.'));
        }, IDB_OPERATION_TIMEOUT_MS);

        const settleResolve = value => {
            if (settled) {
                try { value.close(); } catch { }
                return;
            }

            settled = true;
            clearTimeout(timeoutId);
            resolve(value);
        };

        const settleReject = error => {
            if (settled) {
                return;
            }

            settled = true;
            clearTimeout(timeoutId);
            reject(error || new Error('IndexedDB open failed.'));
        };

        req = indexedDB.open(VULNDB_NAME, VULNDB_VERSION);
        req.onupgradeneeded = () => {
            const db = req.result;
            const store = db.objectStoreNames.contains(VULNDB_STORE)
                ? req.transaction.objectStore(VULNDB_STORE)
                : db.createObjectStore(VULNDB_STORE, { keyPath: 'fingerprint' });
            if (!store.indexNames.contains('ts')) {
                store.createIndex('ts', 'ts');
            }
        };
        req.onsuccess = () => settleResolve(req.result);
        req.onerror = () => settleReject(req.error);
        req.onblocked = () => settleReject(new Error('IndexedDB open was blocked.'));
    });
}

/**
 * Retrieve cached denormalized data from IndexedDB.
 * @param {string} fingerprint
 * @returns {Promise<Array|null>}
 */
async function getCachedData(fingerprint) {
    let db = null;
    try {
        db = await openVulnDB();
        return await new Promise((resolve) => {
            let settled = false;
            const settle = value => {
                if (settled) {
                    return;
                }

                settled = true;
                clearTimeout(timeoutId);
                try { db.close(); } catch { /* ignore close failures */ }
                resolve(value);
            };

            const tx = db.transaction(VULNDB_STORE, 'readonly');
            const store = tx.objectStore(VULNDB_STORE);
            const timeoutId = setTimeout(() => {
                try { tx.abort(); } catch { }
                settle(null);
            }, IDB_OPERATION_TIMEOUT_MS);
            const req = store.get(fingerprint);
            req.onsuccess = () => {
                if (!req.result || req.result.schema !== DERIVED_CACHE_SCHEMA
                    || !Array.isArray(req.result.data)
                    || req.result.data.length >= 500000
                    || !req.result.data.every(row => row && typeof row === 'object' && !Array.isArray(row))
                    || (req.result.lookups && !hasFullDenormalizationLookups(req.result.lookups))) return settle(null);
                // Return both data and cached lookups (if available)
                return settle({ data: req.result.data, lookups: req.result.lookups || null });
            };
            req.onerror = () => settle(null);
            tx.onabort = () => settle(null);
            tx.onerror = () => settle(null);
        });
    } catch (error) {
        logDebug('IndexedDB cache read skipped:', error && error.message ? error.message : error);
        try { db?.close(); } catch { /* ignore close failures */ }
        return null;
    }
}

/**
 * Store denormalized data in IndexedDB cache.
 * Keeps a small rolling window of cache entries so compressed and
 * uncompressed fingerprints can coexist without racing each other out.
 * @param {string} fingerprint
 * @param {Array} data
 */
async function setCachedData(fingerprint, data) {
    if (!Array.isArray(data) || data.length >= 500000) return;
    let db = null;
    try {
        db = await openVulnDB();
        await new Promise(resolve => {
            let settled = false;
            const settle = () => {
                if (settled) {
                    return;
                }

                settled = true;
                clearTimeout(timeoutId);
                try { db.close(); } catch { /* ignore close failures */ }
                resolve();
            };

            const tx = db.transaction(VULNDB_STORE, 'readwrite');
            const store = tx.objectStore(VULNDB_STORE);
            const timeoutId = setTimeout(() => {
                try { tx.abort(); } catch { /* ignore abort failures */ }
                settle();
            }, IDB_OPERATION_TIMEOUT_MS);

            tx.oncomplete = () => settle();
            tx.onerror = () => settle();
            tx.onabort = () => settle();
            try {
                store.put({ fingerprint, data, lookups: lookups || null, schema: DERIVED_CACHE_SCHEMA, ts: Date.now() });
                const pruneRequest = store.index('ts').openKeyCursor(null, 'prev');
                let retained = 0;
                pruneRequest.onsuccess = () => {
                    const cursor = pruneRequest.result;
                    if (!cursor) return;
                    if (++retained > MAX_IDB_CACHE_ENTRIES) store.delete(cursor.primaryKey);
                    cursor.continue();
                };
            } catch (error) {
                try { tx.abort(); } catch { }
                settle();
            }
        });
    } catch (error) {
        logDebug('IndexedDB cache write skipped:', error && error.message ? error.message : error);
        try { db?.close(); } catch { /* ignore close failures */ }
    }
}
