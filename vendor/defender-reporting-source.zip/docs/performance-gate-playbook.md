﻿# Performance Gate Playbook

This playbook keeps performance work measurable while preserving memory headroom for Azure Automation and Function App deployments.

## Gate cadence

| Gate | When | Command | Primary output | Review threshold |
| --- | --- | --- | --- | --- |
| Deterministic preflight | Every PR and before any perf run | `pwsh -NoProfile -File .\build\Invoke-RegressionValidation.ps1` | parser, ScriptAnalyzer, fixture smoke | Must pass |
| Hot phase review | Every refactor that touches normalization, payload generation, validation, or Azure packaging | `pwsh -NoProfile -File .\tests\Invoke-HotPhaseReview.ps1 -DirectoryPath <dataset>` | `hot-phase-review.json`, stdout log, validation audit | Investigate generator or validation phases that regress by more than `5%` or materially shift relative ordering |
| Routine semantic review | When semantic or validation changes need repeatable review during iteration | `pwsh -NoProfile -File .\tests\Invoke-RoutineSemanticReview.ps1` | medium-dataset `hot-phase-review.json`, audit, stdout/stderr logs | Use before escalating to the `synthetic-50k-1_5m` semantic sign-off lane |
| Synthetic benchmark | After a change that appears to improve or regress performance | `pwsh -NoProfile -File .\tests\Measure-BranchVsMainBenchmark.ps1 -CurrentOnly -DatasetPath <dataset> -ResultsOutputPath <path>` | branch benchmark JSON | Investigate local elapsed or peak memory regressions above `10%` |
| Local history capture | After any benchmark you expect to compare again later | `pwsh -NoProfile -File .\tests\Record-BenchmarkHistory.ps1 -BenchmarkResultPath <path>` | `.local\benchmark-history\benchmark-history.jsonl`, `latest-summary.md` | Use for longitudinal local tracking; do not update merge-tracked docs for one-off review datasets |
| Azure acceptance | Before merging perf-sensitive changes and before release packaging changes | `pwsh -NoProfile -File .\build\Invoke-AzureDeploymentValidation.ps1 -AutomationAccountName <name> -FunctionAppName <name>` | live Azure validation artifacts | Investigate runbook or Function App regressions above `10%`; investigate Function execution-unit growth above `15%`; compare the standard large-dataset run against the accepted envelope in `docs/performance-baselines.md` |
| Baseline refresh | After an accepted improvement or a durable dataset change | update `docs/performance-baselines.md` and keep raw JSON under `.local/` | doc summary plus local raw artifacts | Capture only after the new behavior is accepted |

## Dataset cadence

- Use `tests/fixtures/legacy-migration` only for correctness smoke checks.
- Use a smaller synthetic dataset for fast local hot-phase review while iterating.
- Use `benchmark-medium-v1` as the standard durable benchmark dataset for merge-tracked baseline work.
- Use ad hoc larger synthetic or shifted live synthetic datasets only for one-off investigation or stress review.
- Always use Azure for the final large-dataset acceptance check because local results do not predict Function App memory or execution-unit behavior well enough.
- When Azure acceptance runs with `-SkipMdePermissions`, pass `-FunctionExecutionDatasetPath <dataset>` so the Function App execution step reseeds deterministic exports before invocation.

Standard benchmark dataset:
- Dataset id: `benchmark-medium-v1`
- Generator: `pwsh -NoProfile -File .\tests\New-BenchmarkDataset.ps1 -DatasetId benchmark-medium-v1`
- Series capture: `pwsh -NoProfile -File .\tests\Invoke-BenchmarkSeries.ps1 -BenchmarkDatasetId benchmark-medium-v1 -Iterations 3 -IncludePersistentLocalWorkflow`
- Shape: `BalancedMediumHeavy`, `1,500` devices, `120,000` vulnerability rows, seed `20260322`

Standard large Azure acceptance dataset:
- Dataset path: `.local\large-datasets\synthetic-50k-1_5m`
- Shape: `50,000` devices, `1,500,000` vulnerability rows, `3,097` CVEs
- Accepted architecture anchor: `monolithic-v1` with `compiled-bounded-standard-payload` for content-only high-cardinality normalization
- Current Automation gate: true compiled pre-trim working set below `400 MB`; the 2026-07-12 acceptance measured `365.1 MB`, `42.34s` compiled projection time, and `1,187,395` onboarded rows
- Current Function App reference: the 2026-07-13 complete enriched replay published `1,484,239` rows in about `544s` active time, with `816.3 MB` Azure Monitor peak working set and approximately `1,238,425,600` execution units. Track this separately from the Automation ceiling.
- Compare future hosted Azure acceptance runs against the current bounded-path envelope in `docs/performance-baselines.md`; retain the older Function App envelope as a separate historical comparison until it is refreshed

For a guarded candidate run against the real Automation account, use `tests/Invoke-AzureRunbookValidation.ps1` with an explicit subscription, `-ValidatePublishedSemanticParity`, and `-Execute`. The harness backs up and restores the runbook and storage state. Run both the high-cardinality content-only seed and the checked-in `exports` compatibility lane before accepting normalization or memory changes. Large compiled payloads use exact decompressed-byte equality; enriched compatibility payloads use canonical expanded-row equivalence when lookup ordering changes serialized bytes.

## Hosted local runtime checkpoints

Use the local `exports\` lane as a quick browser/runtime checkpoint before escalating to Azure or the large semantic lanes.

Current local reference points on the generated hosted dashboard:

- Critical hosted assets (HTML + `runtime/dashboard.css` + `runtime/dashboard.js` + `runtime/pako.js` + `vendor/chart.js` + `data/summary.json` + `data/payload.json.gz`) are about `1.48 MB` on the local `exports\` lane, with `data/summary.json` contributing only about `2.6 KB`.
- Optional hosted PDF/export assets (`optional/pdf-export.runtime.js` + `optional/pdf-export.bundle.js`) are about `2.39 MB` and should stay off the initial interaction path.
- Hosted Edge headless readiness on the local `exports\` lane is about `12.0 s` (`loadData ~= 28 ms`, `denormalize ~= 12.0 s`, `init ~= 12.0 s`) after the cache/digest/worker hardening work.
- Local dual-package `Write dashboard` is about `2.5 s to 3.1 s` on the same lane.

Review guidance for this lane:

- Investigate if the critical hosted asset set grows by more than `10%` without a deliberate product reason.
- Investigate if hosted readiness on the local `exports\` lane regresses above `15 s` or if `tests\Invoke-HostedDashboardRuntimeSmoke.ps1` stops reaching `dashboard-ready`.
- Investigate if the optional PDF bundle is pulled back onto the initial path instead of remaining on-demand.
- Investigate if local dual-package `Write dashboard` regresses above `10%` on the same lane.

## Recommended workflow

1. Run the deterministic preflight.
2. Run `tests/Invoke-HotPhaseReview.ps1` on the representative local dataset you are using for the refactor.
3. If semantic or validation behavior changed, run `tests/Invoke-RoutineSemanticReview.ps1` before escalating to the large semantic sign-off lane.
4. If validation dominates, run `tests/Invoke-ValidationModeComparison.ps1` to split package-only, force-full validation, and attested validation into separate measured runs.
5. Review the top generator phases plus the audit `PhaseTimings` values from the hot-phase or validation-mode report.
6. Make one focused change at a time and re-run the relevant local review command.
7. Once the local review looks better, refresh `benchmark-medium-v1` if needed and capture a benchmark result with `tests/Measure-BranchVsMainBenchmark.ps1` or `tests/Invoke-BenchmarkSeries.ps1`.
8. If the change is still favorable, validate the large dataset in Azure.
9. Append the benchmark JSON to `.local` history with `tests/Record-BenchmarkHistory.ps1`.
10. Record accepted durable baselines in `docs/performance-baselines.md` and keep raw JSON artifacts under `.local/`.

Guardrails:
- `tests/Invoke-HotPhaseReview.ps1` now defaults to artifact parity review instead of semantic replay.
- Use `-ValidationMode semantic` only when you are intentionally investigating semantic audit cost or validating semantic changes.
- Large local semantic runs above the configured row limit require `-AllowLargeSemanticValidation` so they are not started accidentally.
- `tests/Invoke-HotPhaseReview.ps1`, `tests/Invoke-ValidationModeComparison.ps1`, `tests/Measure-BranchVsMainBenchmark.ps1`, `tests/Measure-StressRun.ps1`, and `tests/Invoke-WithPwshMemoryGuard.ps1` rely on Windows memory-sampling primitives.

Semantic validation guardrails:
- The default local semantic row limit is `1,000,000` rows; the routine medium dataset stays under that limit, while the standard `synthetic-50k-1_5m` sign-off lane does not.
- Use `tests/Invoke-RoutineSemanticReview.ps1` for repeatable branch iteration and reserve `-AllowLargeSemanticValidation` for intentional final-signoff or high-risk investigations.
- Run the large sign-off wrapper as `pwsh -NoProfile -File .\tests\Invoke-LargeDatasetValidation.ps1 -SkipSyntheticGeneration -SyntheticOutputPath .\.local\large-datasets\synthetic-50k-1_5m -Validate -ValidationMode semantic -ForceFullValidation` so semantic sign-off always means a fresh replay instead of attestation reuse.
- For Azure acceptance, prefer the bounded source-reference comparison in `tests/Invoke-AzureRunbookValidation.ps1`; the older full dashboard audit remains useful for compatibility diagnostics but can retain substantially more local state than the production publisher.
- If you need browser-level hosted coverage, pair the deterministic preflight with `tests/Invoke-HostedDashboardRuntimeSmoke.ps1` on Windows instead of escalating directly to the large semantic lane.

Timing interpretation:
- Azure Automation already tracks active execution time from job start to job end.
- Function App benchmark summaries now treat `function_app.elapsed_seconds` as active execution time when the runtime status blob is available.
- Function App invoke-to-finish time remains available as `function_app.end_to_end_elapsed_seconds` so queue delay and cold-start variance can still be reviewed separately.

## Rewrite trigger review

- Use the standard `synthetic-50k-1_5m` Azure acceptance lane as the rewrite-trigger anchor for `monolithic-v1`.
- Do not escalate on a single Azure failure or a single noisy run.
- Investigate any runbook or hosted Function App elapsed or working-set regression above `10%` relative to the accepted envelope in `docs/performance-baselines.md`.
- Investigate any hosted Function App execution-unit growth above `15%`.
- Escalate to the staged rewrite only after two consecutive hosted Function App Azure acceptance failures on the standard large dataset, repeated beyond-threshold regressions that persist after localized fixes, or a new resumability requirement.

## Hot phase interpretation

- If `Load source data` dominates, focus on source readers, decompression paths, and unnecessary materialization.
- If `Normalize source data` dominates, focus on canonicalization, lookup creation, and repeated transforms.
- If `Prepare normalized payload` dominates, focus on payload compression, fallback serialization, and cache publication churn.
- If `Write dashboard` dominates, focus on payload embedding, split-assets behavior, and repeated template work.
- If validation dominates as a whole, run `tests/Invoke-ValidationModeComparison.ps1` before changing audit logic so you can separate package cost from semantic replay cost.
- If validation `Source signatures`, `Payload signatures`, or `Comparison` dominate, focus on attestation reuse, partition sizing, and unnecessary full semantic replays.

## Artifact checklist

- Keep raw review and benchmark output under `.local/`.
- Use `.local\benchmark-history\benchmark-history.jsonl` for repeated local and Azure benchmark captures that are useful for trend review but not yet durable enough for merge-tracked documentation.
- Treat `benchmark-medium-v1` as the durable baseline identity when you are updating merge-tracked baseline documentation.
- Treat `dashboard-audit.json`, `stress-validation-report.json`, and `hot-phase-review.json` as the canonical local review artifacts.
- Use the audit summary to explain why a validation run was slow before changing comparison logic.
- Do not tighten CI thresholds until the same dataset and command path have been repeated enough times to understand normal variance.
