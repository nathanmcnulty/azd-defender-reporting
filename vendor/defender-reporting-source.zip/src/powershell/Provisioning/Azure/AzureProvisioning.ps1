﻿# Source-first Azure provisioning helpers used by Setup-AzureResources.ps1.

$script:LastArmTokenSource = $null

function Get-AzureDashboardConfiguredPdfAssetName {
    [CmdletBinding()]
    [OutputType([string])]
    param(
        [Parameter(Mandatory = $true)][string]$DashboardPath,
        [Parameter(Mandatory = $true)][string]$DashboardBlobName
    )

    $configJson = Get-DashboardHtmlScriptContent -Html (Get-Content -LiteralPath $DashboardPath -Raw) -ScriptId 'dashboardConfig'
    if ([string]::IsNullOrWhiteSpace($configJson)) { return }
    $config = $configJson | ConvertFrom-Json -Depth 20
    $assetRoot = ($DashboardBlobName -replace '\.[^./]+$', '') + '.assets/'
    foreach ($dependency in @('pdfExportRuntime', 'pdfExportBundle')) {
        $mode = $config.PSObject.Properties[($dependency + 'Mode')]
        if ($null -eq $mode -or [string]$mode.Value -ne 'external') { continue }
        $url = $config.PSObject.Properties[($dependency + 'Url')]
        $name = if ($null -ne $url) { [string]$url.Value } else { '' }
        if (-not $name.StartsWith($assetRoot, [System.StringComparison]::Ordinal) -or
            $name -notmatch '^[A-Za-z0-9._/-]+$' -or $name -match '(^|/)\.{1,2}(/|$)|//|/$') {
            throw "Invalid configured published PDF asset '$name'."
        }
        $name
    }
}

function Test-AzurePublishedDashboardEvidence {
    [CmdletBinding()]
    [OutputType([pscustomobject])]
    param(
        [Parameter(Mandatory = $true)][string]$AccountName,
        [Parameter(Mandatory = $true)][ValidateSet('SelfContained', 'Hosted', 'Dual')][string]$DashboardDeliveryMode,
        [Parameter(Mandatory = $true)]$ExpectedTotalRows,
        [Parameter(Mandatory = $true)][string]$ExpectedJobId,
        [Parameter(Mandatory = $true)][datetimeoffset]$NotBefore
    )

    $ExpectedTotalRows = Resolve-AzureValidationExpectedRowCount -ExpectedTotalRows $ExpectedTotalRows
    if (-not (Get-Command Get-DashboardEmbeddedPayloadInspection -ErrorAction SilentlyContinue)) {
        $packagedRuntime = Join-Path $PSScriptRoot 'shared-helpers.ps1'
        if (Test-Path -LiteralPath $packagedRuntime -PathType Leaf) { . $packagedRuntime }
        else { . (Join-Path $PSScriptRoot '..\..\..\..\build\Import-SharedHelpers.ps1') }
    }
    $root = Join-Path ([System.IO.Path]::GetTempPath()) ('setup-dashboard-evidence-' + [guid]::NewGuid().ToString('N'))
    $headers = Get-StorageBlobRestHeaderSet
    $download = {
        param([string]$Name)
        if ([string]::IsNullOrWhiteSpace($Name) -or $Name -match '(^/|\\|:|(^|/)\.\.(/|$))') { throw 'Invalid published blob name.' }
        $path = Join-Path $root ($Name -replace '/', [System.IO.Path]::DirectorySeparatorChar)
        [void](New-Item -Path (Split-Path $path -Parent) -ItemType Directory -Force)
        $encodedName = [System.Uri]::EscapeDataString($Name).Replace('%2F', '/')
        Invoke-WebRequest -Uri "https://$AccountName.blob.core.windows.net/dashboards/$encodedName" -Headers $headers -OutFile $path -UseBasicParsing | Out-Null
        return $path
    }
    try {
        $statusPath = & $download '_diagnostics/ExportAndGenerate.status.json'
        $status = Get-Content -LiteralPath $statusPath -Raw | ConvertFrom-Json -Depth 30
        if ([string]$status.automationJobId -ne $ExpectedJobId -or [datetimeoffset]$status.startedOnUtc -lt $NotBefore -or [string]::IsNullOrWhiteSpace([string]$status.runId)) { throw 'Published status is stale or belongs to a different validation job.' }
        if ([string]$status.dashboardDeliveryMode -ne $DashboardDeliveryMode -or [string]$status.storageAccountName -ne $AccountName -or $status.useExistingExportsOnly -ne $true) { throw 'Published status does not match the seeded validation request.' }
        $dashboardPath = & $download ([string]$status.dashboardBlobName)
        foreach ($asset in @(Get-DashboardRequiredAssetName -Html (Get-Content -LiteralPath $dashboardPath -Raw) -HtmlBlobName ([string]$status.dashboardBlobName))) { $null = & $download $asset }
        if ($DashboardDeliveryMode -in @('Hosted', 'Dual')) {
            $hostedName = if ($DashboardDeliveryMode -eq 'Dual') { [string]$status.hostedDashboardBlobName } else { [string]$status.dashboardBlobName }
            if ($DashboardDeliveryMode -eq 'Dual') {
                $hostedPath = & $download $hostedName
                foreach ($asset in @(Get-DashboardRequiredAssetName -Html (Get-Content -LiteralPath $hostedPath -Raw) -HtmlBlobName $hostedName)) { $null = & $download $asset }
            }
            $hostedLocalPath = if ($DashboardDeliveryMode -eq 'Dual') { $hostedPath } else { $dashboardPath }
            foreach ($asset in @(Get-DashboardRequiredAssetName -Html (Get-Content -LiteralPath $hostedLocalPath -Raw) -HtmlBlobName $hostedName)) { $null = & $download $asset }
        }
        $result = Assert-AzureDashboardCandidateEvidence -DashboardRootPath $root -RunbookStatus $status -DashboardDeliveryMode $DashboardDeliveryMode -ExpectedTotalRows $ExpectedTotalRows -ExpectedJobId $ExpectedJobId -ExpectedRunId ([string]$status.runId) -NotBefore $NotBefore
        $lastStatusPath = & $download '_diagnostics/ExportAndGenerate.status.json'
        $lastStatus = Get-Content -LiteralPath $lastStatusPath -Raw | ConvertFrom-Json -Depth 30
        if ([string]$lastStatus.runId -ne [string]$status.runId -or [string]$lastStatus.updatedOnUtc -ne [string]$status.updatedOnUtc) { throw 'Published status changed during artifact validation.' }
        return $result
    }
    finally {
        if (Test-Path -LiteralPath $root) { Remove-Item -LiteralPath $root -Recurse -Force -ErrorAction SilentlyContinue }
    }
}

function Resolve-AzureValidationExpectedRowCount {
    [CmdletBinding()]
    [OutputType([int])]
    param(
        [Parameter(Mandatory = $false)][string]$DatasetPath,
        [Parameter(Mandatory = $false)]$ExpectedTotalRows
    )

    if ($PSBoundParameters.ContainsKey('ExpectedTotalRows')) {
        $count = $ExpectedTotalRows
        $invalidCountMessage = 'ExpectedTotalRows must be an integer between 1 and 50000000.'
        if ($count -is [string]) {
            $parsedCount = 0
            if ([int]::TryParse($count, [System.Globalization.NumberStyles]::Integer, [System.Globalization.CultureInfo]::InvariantCulture, [ref]$parsedCount)) { $count = $parsedCount }
        }
    }
    else {
        $manifest = $null
        if (-not [string]::IsNullOrWhiteSpace($DatasetPath)) {
            $manifestPath = Join-Path $DatasetPath 'synthetic-manifest.json'
            if (Test-Path -LiteralPath $manifestPath -PathType Leaf) { $manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json -Depth 30 }
        }
        if ($null -eq $manifest -or -not $manifest.PSObject.Properties['expectedDashboardRows']) {
            throw 'ExpectedTotalRows is required: supply an explicit expected onboarded dashboard row count or authoritative expectedDashboardRows in synthetic-manifest.json. Source observation counts are not dashboard row counts.'
        }
        $count = $manifest.expectedDashboardRows
        $invalidCountMessage = 'synthetic-manifest.json expectedDashboardRows must be a JSON integer between 1 and 50000000.'
    }
    $isNumber = $count -is [int] -or $count -is [long] -or $count -is [double] -or $count -is [decimal] -or $count -is [System.Numerics.BigInteger]
    if (-not $isNumber -or $count -lt 1 -or $count -gt 50000000 -or $count -ne [math]::Truncate([double]$count)) { throw $invalidCountMessage }
    return [int]$count
}

function Assert-AzureDashboardCandidateEvidence {
    [CmdletBinding()]
    [OutputType([pscustomobject])]
    param(
        [Parameter(Mandatory = $true)][string]$DashboardRootPath,
        [Parameter(Mandatory = $true)]$RunbookStatus,
        [Parameter(Mandatory = $true)][ValidateSet('SelfContained', 'Hosted', 'Dual')][string]$DashboardDeliveryMode,
        [Parameter(Mandatory = $true)]$ExpectedTotalRows,
        [Parameter(Mandatory = $false)][scriptblock]$PayloadRowCounter,
        [Parameter(Mandatory = $false)][string]$ExpectedRunId,
        [Parameter(Mandatory = $false)][string]$ExpectedJobId,
        [Parameter(Mandatory = $false)][datetimeoffset]$NotBefore
    )

    $ExpectedTotalRows = Resolve-AzureValidationExpectedRowCount -ExpectedTotalRows $ExpectedTotalRows
    if ([string]$RunbookStatus.status -ne 'succeeded' -or [string]$RunbookStatus.stage -ne 'Completed') { throw 'Runbook status evidence is not a succeeded Completed document.' }
    if ($ExpectedRunId -and [string]$RunbookStatus.runId -ne $ExpectedRunId) { throw 'Runbook status belongs to a different job/run identity.' }
    if ($ExpectedJobId -and [string]$RunbookStatus.automationJobId -ne $ExpectedJobId) { throw 'Runbook status belongs to a different Automation job.' }
    if ([string]::IsNullOrWhiteSpace([string]$RunbookStatus.runId)) { throw 'Runbook status is missing runId.' }
    if ($PSBoundParameters.ContainsKey('NotBefore') -and [datetimeoffset]$RunbookStatus.startedOnUtc -lt $NotBefore) { throw 'Runbook status predates the current validation job.' }
    if ([int64]$RunbookStatus.vulnerabilities -ne $ExpectedTotalRows) { throw "Runbook status reported $($RunbookStatus.vulnerabilities) vulnerabilities; expected $ExpectedTotalRows." }
    foreach ($countName in @('devices', 'cves')) {
        if (-not $RunbookStatus.PSObject.Properties[$countName] -or [int]$RunbookStatus.$countName -le 0) { throw "Runbook status is missing a positive '$countName' count." }
    }

    $root = [System.IO.Path]::GetFullPath($DashboardRootPath) + [System.IO.Path]::DirectorySeparatorChar
    $resolveArtifact = {
        param([string]$Name)
        if ([string]::IsNullOrWhiteSpace($Name) -or [System.IO.Path]::IsPathRooted($Name) -or $Name.Contains(':')) { throw 'Invalid published artifact name.' }
        $path = [System.IO.Path]::GetFullPath((Join-Path $root ($Name -replace '/', [System.IO.Path]::DirectorySeparatorChar)))
        if (-not $path.StartsWith($root, [System.StringComparison]::OrdinalIgnoreCase)) { throw 'Published artifact escapes the dashboard root.' }
        if (-not (Test-Path -LiteralPath $path -PathType Leaf) -or (Get-Item -LiteralPath $path).Length -eq 0) { throw "Published dashboard asset '$Name' is missing or empty." }
        if ($ExpectedJobId) {
            $expectedHash = [string]$RunbookStatus.artifactSha256.PSObject.Properties[$Name].Value
            if ($expectedHash -notmatch '^[0-9a-f]{64}$' -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expectedHash) { throw "Published artifact '$Name' SHA-256 does not match the current job status." }
        }
        return $path
    }
    $dashboardBlobName = [string]$RunbookStatus.dashboardBlobName
    $dashboardPath = & $resolveArtifact $dashboardBlobName
    foreach ($asset in @(Get-DashboardRequiredAssetName -Html (Get-Content -LiteralPath $dashboardPath -Raw) -HtmlBlobName $dashboardBlobName)) { $null = & $resolveArtifact $asset }
    $result = [ordered]@{
        dashboard_blob_name = $dashboardBlobName
        dashboard_sha256 = (Get-FileHash -LiteralPath $dashboardPath -Algorithm SHA256).Hash.ToLowerInvariant()
        dashboard_bytes = [int64](Get-Item -LiteralPath $dashboardPath).Length
        vulnerabilities = [int64]$RunbookStatus.vulnerabilities
        devices = [int]$RunbookStatus.devices
        cves = [int]$RunbookStatus.cves
        hosted_assets_validated = $false
    }

    $embedded = $null
    if ($DashboardDeliveryMode -in @('SelfContained', 'Dual')) {
        $embedded = Get-DashboardEmbeddedPayloadInspection -Path $dashboardPath
        if ($embedded.DataFormat -ne 'compressed' -or $embedded.PayloadRowCount -ne $ExpectedTotalRows) { throw 'Self-contained payload format/count does not match the expected dashboard rows.' }
        $result['payload_row_count'] = $embedded.PayloadRowCount
        $result['payload_sha256'] = $embedded.PayloadSha256
    }
    if ($DashboardDeliveryMode -in @('Hosted', 'Dual')) {
        $hostedBlobName = if ($DashboardDeliveryMode -eq 'Dual') { [string]$RunbookStatus.hostedDashboardBlobName } else { $dashboardBlobName }
        $hostedPath = & $resolveArtifact $hostedBlobName
        if ($DashboardDeliveryMode -eq 'Dual') {
            foreach ($asset in @(Get-DashboardRequiredAssetName -Html (Get-Content -LiteralPath $hostedPath -Raw) -HtmlBlobName $hostedBlobName)) { $null = & $resolveArtifact $asset }
        }
        $assetDirectoryName = (Get-DashboardPublishedAssetPrefix -Html (Get-Content -LiteralPath $hostedPath -Raw) -HtmlBlobName $hostedBlobName).TrimEnd('/')
        foreach ($asset in @(Get-DashboardRequiredAssetName -Html (Get-Content -LiteralPath $hostedPath -Raw) -HtmlBlobName $hostedBlobName)) { $null = & $resolveArtifact $asset }
        $payloadPath = & $resolveArtifact "$assetDirectoryName/data/payload.json.gz"
        $summaryPath = & $resolveArtifact "$assetDirectoryName/data/summary.json"
        $summary = Get-Content -LiteralPath $summaryPath -Raw | ConvertFrom-Json -Depth 30
        $payloadSha256 = (Get-FileHash -LiteralPath $payloadPath -Algorithm SHA256).Hash.ToLowerInvariant()
        if ([string]$summary.meta.payloadSha256 -ne $payloadSha256) { throw 'Hosted payload SHA-256 does not match summary metadata.' }
        if ([int64]$summary.meta.vulnCount -ne $ExpectedTotalRows) { throw 'Hosted summary vulnerability count does not match the expected row count.' }
        if ([int]$summary.meta.deviceCount -ne [int]$RunbookStatus.devices -or [int]$summary.meta.cveCount -ne [int]$RunbookStatus.cves) { throw 'Hosted summary device/CVE counts do not match runbook status.' }
        $payloadRowCount = if ($PayloadRowCounter) { & $PayloadRowCounter $payloadPath } else { Get-CompressedPayloadVulnCount -Path $payloadPath }
        if ($payloadRowCount -ne $ExpectedTotalRows) { throw "Published payload contains $payloadRowCount rows; expected $ExpectedTotalRows." }
        if ($embedded -and $embedded.PayloadSha256 -ne $payloadSha256) { throw 'Dual self-contained and hosted payload SHA-256 identities differ.' }
        $hostedHtml = Get-Content -LiteralPath $hostedPath -Raw
        foreach ($relativeAssetPath in @('data/payload.json.gz', 'data/summary.json', 'runtime/dashboard.js')) {
            if (-not $hostedHtml.Contains("$assetDirectoryName/$relativeAssetPath")) { throw "Hosted dashboard HTML does not reference '$relativeAssetPath'." }
        }
        $result['hosted_blob_name'] = $hostedBlobName
        $result['hosted_payload_blob_name'] = "$assetDirectoryName/data/payload.json.gz"
        $result['payload_sha256'] = $payloadSha256
        $result['payload_row_count'] = [int64]$payloadRowCount
        $result['payload_bytes'] = [int64](Get-Item -LiteralPath $payloadPath).Length
        $result['summary_sha256'] = (Get-FileHash -LiteralPath $summaryPath -Algorithm SHA256).Hash.ToLowerInvariant()
        $result['hosted_assets_validated'] = $true
    }
    return [PSCustomObject]$result
}

function Write-ProvisioningLogLine {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Message,

        [Parameter(Mandatory = $false)]
        [string]$ForegroundColor = 'Gray'
    )

    if ([string]::IsNullOrWhiteSpace($Message)) {
        return
    }

    foreach ($line in ($Message -split "`r?`n")) {
        if ([string]::IsNullOrWhiteSpace($line)) {
            continue
        }

        Write-Host ("[{0}] {1}" -f (Get-Date).ToUniversalTime().ToString('u'), $line) -ForegroundColor $ForegroundColor
    }
}

function Wait-WithPolling {
    <#
    .SYNOPSIS
        Polls a script block every $IntervalSeconds until it returns $true or timeout.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [scriptblock]$Condition,

        [Parameter(Mandatory)]
        [string]$Description,

        [int]$IntervalSeconds = 5,
        [int]$TimeoutSeconds = 60
    )

    $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
    while ($stopwatch.Elapsed.TotalSeconds -lt $TimeoutSeconds) {
        if (& $Condition) {
            Write-ProvisioningLogLine -Message ("  {0} - confirmed" -f $Description) -ForegroundColor Green
            return $true
        }
        Write-ProvisioningLogLine -Message ("  Waiting for {0}... ({1}s)" -f $Description, [int]$stopwatch.Elapsed.TotalSeconds) -ForegroundColor Gray
        Start-Sleep -Seconds $IntervalSeconds
    }
    $stopwatch.Stop()
    Write-Warning ("[{0}] {1} did not complete within {2}s" -f (Get-Date).ToUniversalTime().ToString('u'), $Description, $TimeoutSeconds)
    return $false
}

function Invoke-ArmApi {
    <#
    .SYNOPSIS
        Thin ARM wrapper that prefers Invoke-AzRestMethod and falls back to an explicit bearer token when the current Az session cannot refresh ARM tokens.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Path,

        [Parameter(Mandatory)]
        [ValidateSet('GET', 'PUT', 'POST', 'PATCH', 'DELETE')]
        [string]$Method,

        [string]$Payload,

        [string]$Description = 'ARM API call'
    )

    $requestUri = if ($Path -match '^https?://') {
        $Path
    }
    elseif ($Path.StartsWith('/')) {
        "https://management.azure.com$Path"
    }
    else {
        "https://management.azure.com/$Path"
    }

    $params = @{
        Uri = $requestUri
        Method = $Method
        ErrorAction = 'Stop'
    }
    if ($Payload) {
        $params.Payload = $Payload
    }

    $response = $null
    $shouldFallbackToExplicitToken = $false
    $fallbackReason = $null
    try {
        $response = Invoke-AzRestMethod @params
    }
    catch {
        Write-Verbose ("Invoke-AzRestMethod could not complete '{0}': {1}" -f $Description, $_.Exception.Message)
        $shouldFallbackToExplicitToken = $true
        $fallbackReason = $_.Exception.Message
    }

    if ($null -eq $response) {
        Write-Verbose ("Invoke-AzRestMethod returned no response for '{0}'. Falling back to explicit token acquisition." -f $Description)
        $shouldFallbackToExplicitToken = $true
        if ([string]::IsNullOrWhiteSpace($fallbackReason)) {
            $fallbackReason = 'Invoke-AzRestMethod returned no response.'
        }
    }

    if ($null -ne $response -and [int]$response.StatusCode -eq 401) {
        Write-Verbose ("Invoke-AzRestMethod returned HTTP 401 for '{0}'. Falling back to explicit token acquisition." -f $Description)
        $shouldFallbackToExplicitToken = $true
        $fallbackReason = 'Invoke-AzRestMethod returned HTTP 401.'
    }

    if ($shouldFallbackToExplicitToken) {
        $accessToken = Get-ArmToken
        $tokenSource = if ([string]::IsNullOrWhiteSpace($script:LastArmTokenSource)) { 'explicit bearer token' } else { $script:LastArmTokenSource }
        Write-ProvisioningLogLine -Message ("  ARM auth fallback for {0}: {1} Token source: {2}." -f $Description, $fallbackReason, $tokenSource) -ForegroundColor Yellow
        $fallbackParams = @{
            Uri = $requestUri
            Method = $Method
            Headers = @{
                Authorization = "Bearer $accessToken"
            }
            ErrorAction = 'Stop'
            SkipHttpErrorCheck = $true
        }
        if ($Payload) {
            $fallbackParams.ContentType = 'application/json'
            $fallbackParams.Body = $Payload
        }

        $response = Invoke-WebRequest @fallbackParams
    }

    if ($response.StatusCode -ge 200 -and $response.StatusCode -lt 300) {
        if ($response.Content) {
            return $response.Content | ConvertFrom-Json
        }
        return $null
    }

    $errorDetail = ''
    if ($response.Content) {
        try {
            $errorBody = $response.Content | ConvertFrom-Json
            $errorDetail = if ($errorBody.error.message) { $errorBody.error.message }
            elseif ($errorBody.message) { $errorBody.message }
            else { $response.Content }
        }
        catch { $errorDetail = $response.Content }
    }

    throw "$Description failed (HTTP $($response.StatusCode)): $errorDetail"
}

function Get-ErrorMessageText {
    [CmdletBinding()]
    [OutputType([string])]
    param(
        [Parameter(Mandatory = $true)]
        [System.Management.Automation.ErrorRecord]$ErrorRecord
    )

    $parts = [System.Collections.Generic.List[string]]::new()
    if ($ErrorRecord.Exception -and -not [string]::IsNullOrWhiteSpace($ErrorRecord.Exception.Message)) {
        $parts.Add($ErrorRecord.Exception.Message)
    }
    if ($ErrorRecord.ErrorDetails -and -not [string]::IsNullOrWhiteSpace($ErrorRecord.ErrorDetails.Message)) {
        $parts.Add($ErrorRecord.ErrorDetails.Message)
    }

    return ($parts -join "`n")
}

function Test-IsArmNotFoundError {
    [CmdletBinding()]
    [OutputType([bool])]
    param(
        [Parameter(Mandatory = $true)]
        [System.Management.Automation.ErrorRecord]$ErrorRecord
    )

    $text = Get-ErrorMessageText -ErrorRecord $ErrorRecord
    return ($text -match '(?i)\b(HTTP\s*404|StatusCode\s*:?\s*404|ResourceGroupNotFound|ResourceNotFound|NotFound|could not be found|was not found)\b')
}

function Remove-AutomationJobSchedulesByScheduleName {
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseShouldProcessForStateChangingFunctions', '')]
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$SubscriptionPath,

        [Parameter(Mandatory)]
        [string]$ResourceGroupName,

        [Parameter(Mandatory)]
        [string]$AutomationAccountName,

        [Parameter(Mandatory)]
        [string]$ScheduleName
    )

    $jobSchedulesPath = "$SubscriptionPath/resourceGroups/$ResourceGroupName/providers/Microsoft.Automation/automationAccounts/$AutomationAccountName/jobSchedules?api-version=$($Script:ArmApiVersions.AutomationAccount)"
    $jobSchedulesResponse = Invoke-ArmApi -Path $jobSchedulesPath -Method GET -Description 'List Automation job schedules'
    $jobSchedules = if ($null -eq $jobSchedulesResponse) {
        @()
    }
    elseif ($jobSchedulesResponse.PSObject.Properties['value']) {
        @($jobSchedulesResponse.value)
    }
    else {
        @($jobSchedulesResponse)
    }

    foreach ($jobSchedule in $jobSchedules) {
        if ($null -eq $jobSchedule) { continue }

        $jobScheduleName = ''
        if ($jobSchedule.PSObject.Properties['name']) {
            $jobScheduleName = [string]$jobSchedule.PSObject.Properties['name'].Value
        }
        if ([string]::IsNullOrWhiteSpace($jobScheduleName)) {
            $jobScheduleName = [string]$jobSchedule.properties.jobScheduleId
        }
        if ([string]::IsNullOrWhiteSpace($jobScheduleName) -and -not [string]::IsNullOrWhiteSpace([string]$jobSchedule.id)) {
            $jobScheduleName = Split-Path -Path ([string]$jobSchedule.id) -Leaf
        }

        $linkedScheduleName = ''
        if ($null -ne $jobSchedule.properties -and $null -ne $jobSchedule.properties.schedule) {
            $linkedScheduleName = [string]$jobSchedule.properties.schedule.name
        }

        if ([string]::IsNullOrWhiteSpace($jobScheduleName) -or $linkedScheduleName -ne $ScheduleName) {
            continue
        }

        $deletePath = "$SubscriptionPath/resourceGroups/$ResourceGroupName/providers/Microsoft.Automation/automationAccounts/$AutomationAccountName/jobSchedules/${jobScheduleName}?api-version=$($Script:ArmApiVersions.AutomationAccount)"
        Invoke-ArmApi -Path $deletePath -Method DELETE -Description "Delete Automation job schedule '$jobScheduleName'" | Out-Null
        Write-Host "  Removed existing job schedule link '$jobScheduleName' for schedule '$ScheduleName'" -ForegroundColor Gray
    }
}

function Get-ArmToken {
    <#
    .SYNOPSIS
        Gets a plain-text ARM bearer token (handles SecureString in newer Az.Accounts).
    #>
    [CmdletBinding()]
    param(
        [string]$ResourceUrl = 'https://management.azure.com/'
    )

    $script:LastArmTokenSource = $null
    try {
        $tokenResponse = Get-AzAccessToken -ResourceUrl $ResourceUrl -AsSecureString -ErrorAction Stop
        $script:LastArmTokenSource = 'Az.Accounts Get-AzAccessToken'
        $ssPtr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($tokenResponse.Token)
        try { return [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($ssPtr) }
        finally { [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ssPtr) }
    }
    catch {
        Write-Verbose "Get-AzAccessToken failed for '$ResourceUrl': $_"
    }

    if ($null -ne (Get-Command -Name 'az' -CommandType Application -ErrorAction SilentlyContinue)) {
        try {
            $azAccessToken = (& az 'account' 'get-access-token' '--resource' $ResourceUrl '--query' 'accessToken' '-o' 'tsv' 2>&1 | Out-String)
            if ($LASTEXITCODE -eq 0 -and -not [string]::IsNullOrWhiteSpace($azAccessToken)) {
                $script:LastArmTokenSource = 'Azure CLI az account get-access-token'
                Write-ProvisioningLogLine -Message ("  Token fallback for resource {0}: using Azure CLI access token." -f $ResourceUrl) -ForegroundColor Yellow
                return $azAccessToken.Trim()
            }

            if ($LASTEXITCODE -ne 0 -and -not [string]::IsNullOrWhiteSpace($azAccessToken)) {
                Write-Verbose ("Azure CLI token acquisition failed for '{0}': {1}" -f $ResourceUrl, $azAccessToken.Trim())
            }
        }
        catch {
            Write-Verbose "Azure CLI token acquisition failed for '$ResourceUrl': $_"
        }
    }

    throw "No Azure token source available for resource '$ResourceUrl'. Run Connect-AzAccount or az login, then retry."
}

function Get-JwtPayload {
    <#
    .SYNOPSIS
        Decodes the payload segment from a JWT bearer token.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Token
    )

    $parts = $Token.Split('.')
    if ($parts.Count -lt 2) {
        throw 'Token is not a valid JWT.'
    }

    $payload = $parts[1].Replace('-', '+').Replace('_', '/')
    switch ($payload.Length % 4) {
        2 { $payload += '==' }
        3 { $payload += '=' }
        0 { }
        default { throw 'JWT payload is not valid Base64Url.' }
    }

    $json = [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($payload))
    return $json | ConvertFrom-Json
}

function Get-GraphApiTenantId {
    [CmdletBinding()]
    [OutputType([string])]
    param(
        [Parameter(Mandatory)]
        $Context
    )

    $modeProperty = $Context.PSObject.Properties['Mode']
    if ($null -eq $modeProperty -or $modeProperty.Value -isnot [string]) {
        throw 'Unsupported Graph API context mode for tenant resolution.'
    }
    $tenantValue = $null
    switch ($modeProperty.Value) {
        'AzToken' {
            $tokenProperty = $Context.PSObject.Properties['AccessToken']
            if ($null -eq $tokenProperty -or $tokenProperty.Value -isnot [string] -or
                [string]::IsNullOrWhiteSpace($tokenProperty.Value)) {
                throw 'Graph AzToken context requires a plain-text access token from Get-GraphApiContext.'
            }
            try {
                if ($tokenProperty.Value.Split('.').Count -ne 3) { throw 'Invalid JWT structure.' }
                $payloadSegment = $tokenProperty.Value.Split('.')[1].Replace('-', '+').Replace('_', '/')
                switch ($payloadSegment.Length % 4) {
                    2 { $payloadSegment += '==' }
                    3 { $payloadSegment += '=' }
                    0 { }
                    default { throw 'Invalid JWT payload encoding.' }
                }
                $payloadJson = [Text.UTF8Encoding]::new($false, $true).GetString([Convert]::FromBase64String($payloadSegment))
                $payload = ConvertFrom-Json -InputObject $payloadJson -NoEnumerate -ErrorAction Stop
                if ($payload -isnot [System.Management.Automation.PSCustomObject]) { throw 'Invalid JWT claims object.' }
                $tenantProperty = $payload.PSObject.Properties['tid']
                if ($null -ne $tenantProperty) { $tenantValue = $tenantProperty.Value }
            }
            catch {
                throw 'Could not decode the Graph access token tenant claim.'
            }
        }
        'MgGraph' {
            $connectedContext = Get-MgContext -ErrorAction Stop
            if ($null -ne $connectedContext) {
                $tenantProperty = $connectedContext.PSObject.Properties['TenantId']
                if ($null -ne $tenantProperty) { $tenantValue = $tenantProperty.Value }
            }
        }
        default { throw 'Unsupported Graph API context mode for tenant resolution.' }
    }

    $tenantGuid = [guid]::Empty
    if ($tenantValue -isnot [string] -or
        -not [guid]::TryParse($tenantValue, [ref]$tenantGuid) -or
        $tenantGuid -eq [guid]::Empty) {
        throw 'The active Graph context must provide a non-empty tenant GUID string.'
    }
    return $tenantGuid.ToString('D')
}

function Get-GrantedScopesFromToken {
    <#
    .SYNOPSIS
        Returns delegated scopes from a JWT's scp claim.
    #>
    [CmdletBinding()]
    [OutputType([string[]])]
    param(
        [Parameter(Mandatory)]
        [string]$AccessToken
    )

    $payload = Get-JwtPayload -Token $AccessToken
    $scopeClaim = if ($payload.PSObject.Properties['scp']) { [string]$payload.scp } else { '' }
    if ([string]::IsNullOrWhiteSpace($scopeClaim)) {
        return @()
    }

    return @(
        $scopeClaim -split '\s+' |
            Where-Object { -not [string]::IsNullOrWhiteSpace($_) } |
            Sort-Object -Unique
    )
}

function Test-GraphScopeRequirement {
    <#
    .SYNOPSIS
        Checks whether a granted scope set satisfies the requested requirements.
    #>
    [CmdletBinding()]
    param(
        [string[]]$GrantedScopes = @(),
        [string[]]$RequiredAllScopes = @(),
        [string[]]$RequiredAnyScopeSets = @()
    )

    $grantedSet = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($scope in @($GrantedScopes)) {
        if (-not [string]::IsNullOrWhiteSpace($scope)) {
            [void]$grantedSet.Add($scope)
        }
    }

    $missingRequirements = [System.Collections.Generic.List[string]]::new()

    foreach ($scope in @($RequiredAllScopes)) {
        if (-not $grantedSet.Contains($scope)) {
            $missingRequirements.Add($scope)
        }
    }

    foreach ($scopeSet in @($RequiredAnyScopeSets)) {
        $candidateScopes = @(
            ([string]$scopeSet -split '\|') |
                Where-Object { -not [string]::IsNullOrWhiteSpace($_) }
        )
        if ($candidateScopes.Count -eq 0) {
            continue
        }

        $isSatisfied = $false
        foreach ($candidate in $candidateScopes) {
            if ($grantedSet.Contains($candidate)) {
                $isSatisfied = $true
                break
            }
        }

        if (-not $isSatisfied) {
            $missingRequirements.Add(($candidateScopes -join ' or '))
        }
    }

    return [PSCustomObject]@{
        IsSatisfied = ($missingRequirements.Count -eq 0)
        MissingRequirements = @($missingRequirements)
    }
}

function Get-GraphApiContext {
    <#
    .SYNOPSIS
        Creates a Graph API context using Az-issued tokens first, then falls back
        to Microsoft.Graph.Authentication when the Az token lacks required scopes.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Scenario,

        [string[]]$RequiredAllScopes = @(),

        [string[]]$RequiredAnyScopeSets = @(),

        [string[]]$FallbackScopes = @()
    )

    $graphToken = Get-ArmToken -ResourceUrl $Script:GraphApiBaseUrl
    $grantedScopes = Get-GrantedScopesFromToken -AccessToken $graphToken
    $scopeStatus = Test-GraphScopeRequirement -GrantedScopes $grantedScopes -RequiredAllScopes $RequiredAllScopes -RequiredAnyScopeSets $RequiredAnyScopeSets

    if ($scopeStatus.IsSatisfied) {
        Write-Host "  Using Az-issued Microsoft Graph token for $Scenario" -ForegroundColor Green
        return [PSCustomObject]@{
            Mode = 'AzToken'
            AccessToken = $graphToken
            GrantedScopes = $grantedScopes
        }
    }

    $requiredScopeList = @($FallbackScopes | Sort-Object -Unique)
    $missingText = if ($scopeStatus.MissingRequirements.Count -gt 0) {
        $scopeStatus.MissingRequirements -join ', '
    }
    else {
        'unknown'
    }

    Write-Host "  Az-issued Microsoft Graph token is missing required delegated scopes for $Scenario." -ForegroundColor Yellow
    Write-Host "  Missing requirements: $missingText" -ForegroundColor Yellow

    if (Get-Module -ListAvailable -Name Microsoft.Graph.Authentication) {
        Import-Module Microsoft.Graph.Authentication -ErrorAction Stop
        if ($requiredScopeList.Count -eq 0) {
            throw "Fallback scopes were not provided for Graph scenario '$Scenario'."
        }

        Write-Host '  Falling back to Microsoft.Graph.Authentication...' -ForegroundColor Gray
        Connect-MgGraph -Scopes $requiredScopeList -NoWelcome -ErrorAction Stop
        return [PSCustomObject]@{
            Mode = 'MgGraph'
            RequestedScopes = $requiredScopeList
        }
    }

    $scopeHint = $requiredScopeList -join ', '
    throw @"
Microsoft Graph delegated permissions are missing for $Scenario.
Az issued a Graph token without the required delegated scopes.
Missing requirements: $missingText

To continue, either:
  1. install the fallback module and re-run:
     Install-Module Microsoft.Graph.Authentication -Scope CurrentUser
  2. have an Entra admin grant these delegated Microsoft Graph permissions to the '$($Script:AzPowerShellGraphAppName)' enterprise application, then re-run:
     $scopeHint

The signed-in user still needs the appropriate Entra role, such as Application Administrator.
"@
}

function Invoke-GraphApi {
    <#
    .SYNOPSIS
        Wrapper for Microsoft Graph REST calls using either Az tokens or the
        Microsoft.Graph.Authentication fallback session.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        $Context,

        [Parameter(Mandatory)]
        [string]$Uri,

        [Parameter(Mandatory)]
        [ValidateSet('GET', 'POST', 'PATCH', 'PUT', 'DELETE')]
        [string]$Method,

        $Body,

        [string]$Description = 'Microsoft Graph API call'
    )

    $requestUri = if ($Uri -match '^https?://') { $Uri } else { "$($Script:GraphApiBaseUrl)$Uri" }

    try {
        if ($Context.Mode -eq 'AzToken') {
            $headers = @{
                Authorization = "Bearer $($Context.AccessToken)"
            }

            $invokeParams = @{
                Uri = $requestUri
                Method = $Method
                Headers = $headers
                ErrorAction = 'Stop'
            }

            if ($null -ne $Body) {
                $invokeParams.ContentType = 'application/json'
                $invokeParams.Body = if ($Body -is [string]) { $Body } else { $Body | ConvertTo-Json -Depth 20 }
            }

            return Invoke-RestMethod @invokeParams
        }

        if ($Context.Mode -eq 'MgGraph') {
            $invokeParams = @{
                Uri = $Uri
                Method = $Method
                ErrorAction = 'Stop'
            }

            if ($null -ne $Body) {
                $invokeParams.Body = $Body
            }

            return Invoke-MgGraphRequest @invokeParams
        }

        throw "Unsupported Graph context mode '$($Context.Mode)'."
    }
    catch {
        $errorDetail = $_.Exception.Message
        if ($_.ErrorDetails -and $_.ErrorDetails.Message) {
            $errorDetail = $_.ErrorDetails.Message
        }

        throw "$Description failed: $errorDetail"
    }
}