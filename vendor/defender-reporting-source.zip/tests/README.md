# Tests

This folder contains lightweight PowerShell regression coverage for the Defender reporting pipeline.

Maintained PowerShell entrypoints require PowerShell 7.6 or later. The bespoke runtime and inventory regressions run in deterministic preflight; they do not require Pester. See [the baseline policy](../docs/powershell-baseline.md).

## Layout

- `tests/fixtures/` contains committed, minimal synthetic regression datasets, never live exports.
- `tests/manual/` contains ad hoc troubleshooting harnesses that are useful during development but are not part of `build/Invoke-RegressionValidation.ps1`.
- The top-level scripts in `tests/` are the supported automation entrypoints for regression validation, stress generation, benchmarking, and synthetic live-export creation.

## Platform support

Some entrypoints are cross-platform and some depend on Windows memory-sampling primitives or Microsoft Edge.

| Entrypoint | Windows | macOS | Linux | Notes |
| --- | --- | --- | --- | --- |
| `build/Invoke-RegressionValidation.ps1` | Yes | Yes | Yes | Primary deterministic preflight |
| `build/Invoke-LiveDashboardDryRun.ps1` | Yes | Yes | Yes | Requires the right Az/auth context |
| `tests/Invoke-HotPhaseReview.ps1` | Yes | No | No | Uses Windows memory/process sampling |
| `tests/Invoke-ValidationModeComparison.ps1` | Yes | No | No | Uses Windows memory/process sampling |
| `tests/Measure-BranchVsMainBenchmark.ps1` | Yes | No | No | Uses Windows memory/process sampling |
| `tests/Measure-StressRun.ps1` | Yes | No | No | Uses Windows memory/process sampling |
| `tests/Invoke-WithPwshMemoryGuard.ps1` | Yes | No | No | Uses Windows memory/process sampling |
| `tests/Invoke-HostedDashboardRuntimeSmoke.ps1` | Yes | No | No | Requires Microsoft Edge; use `-AllowSkip` when optional |

## Deterministic preflight entrypoint

Run the full local regression bundle with:

```powershell
pwsh -NoProfile -File .\build\Invoke-RegressionValidation.ps1
```

That script is the authoritative deterministic preflight used for local work and PR validation. It rebuilds the generated deployment artifacts, runs parser and PSScriptAnalyzer checks across source scripts, executes focused shared-helper regression tests, and performs a small dashboard fixture smoke generation.

The shared-helper regression lane now logs `START <Test-Name>` and a per-test elapsed time. If the preflight looks slow, use that output to identify the active or expensive test before assuming the suite is hung.

`Test-VulnDeviceProfileProjectionParity` publishes tiny current/history
stores through the default compiled publisher and the partitioned publisher,
then compares every represented v1 field, JSON type and property/array order
against an independent projection. It covers different profiles sharing one
device ID, missing and nonempty OS versions, case and separator collisions,
unchanged raw canonical files, and existing dictionaries. Device identity keys
include the complete projected profile; `RbacGroupId` remains intentionally
outside the v1 schema. Old dictionaries remain readable but do not recover
previously discarded values without republication from canonical raw rows.
More distinct profiles may increase dictionary size and memory; these tiny
correctness checks establish no performance, full-scale or Azure acceptance.

## Test lanes at a glance

The first-run/empty-enrichment and Azure export-generation protocol regressions
run in deterministic preflight:

```powershell
pwsh -NoProfile -File ./tests/Invoke-FirstExportRegression.ps1
pwsh -NoProfile -File ./tests/Invoke-AtomicExportPublicationRegression.ps1
node ./tests/Assert-DashboardScopePdfConsistency.js
```

The PDF scope test always checks the production extraction/snapshot paths. For
actual pdfmake layout and PDF-byte generation, set `PDFMAKE_TEST_LIBRARY` and
`PDFMAKE_TEST_FONTS` to the existing pinned `pdfmake` and `vfs_fonts` JavaScript
files before running it. Without those files it explicitly reports that real
PDF generation was not run. Image capture in this Node test is stubbed; browser
canvas rendering, visual readability and the final user download remain separate.

See [the generation protocol](../docs/export-generation-publication.md) for
legacy cutover, failure recovery and retention boundaries. The in-memory storage
test does not establish actual Azure conditional requests or runtime acceptance.

| Lane | Primary entrypoint | Use it for |
| --- | --- | --- |
| Deterministic regression gate | `build/Invoke-RegressionValidation.ps1` | Every PR and before heavier validation |
| Live export integration | `build/Invoke-LiveDashboardDryRun.ps1 -UseExistingAzContext` | Export/authentication/shipped-dashboard changes |
| Hosted browser/runtime smoke | `tests/Invoke-HostedDashboardRuntimeSmoke.ps1` | Split-assets delivery or hosted runtime changes |
| Local perf phase review | `tests/Invoke-HotPhaseReview.ps1` | Normalization, payload, validation, or packaging perf work |
| Routine semantic review | `tests/Invoke-RoutineSemanticReview.ps1` | Repeatable medium-dataset semantic review during iteration |
| Benchmarking and stress tools | `tests/Invoke-BenchmarkSeries.ps1`, `tests/Measure-BranchVsMainBenchmark.ps1`, `tests/Measure-StressRun.ps1` | Comparative or historical performance work |
| Manual diagnostics | `tests/manual/` | Ad hoc troubleshooting only |

Helper rule: if a new test or benchmark script needs shared utilities, put them in `tests/helpers/` instead of copying helper functions into multiple entrypoints.

## Guarded worker-transfer measurements

`Measure-DashboardWorkerTransfer.js` is a Windows/Edge measurement harness, not a worker-transfer optimization. Its browser-free safety probes also run through the existing telemetry regression in deterministic preflight:

```powershell
node .\tests\Measure-DashboardWorkerTransfer.js --mock
node .\tests\Measure-DashboardWorkerTransfer.js --ownership
node .\tests\Measure-DashboardWorkerTransfer.js --privacy
node .\tests\Assert-DashboardTelemetry.js
```

For an actual measurement, set `PLAYWRIGHT_MODULE` to an installed Playwright module and supply the retained Hosted dashboard directory, a private evidence destination, repeats (1-10), and an explicit expected normalized row count:

```powershell
node .\tests\Measure-DashboardWorkerTransfer.js .\.local\two-row-control .\.local\worker-control.json 1 2 --positive-control
```

Use the committed `fixtures/legacy-migration` dataset through the normal generator for the two-row control; never infer a large normalized count from raw source observations. Run full deterministic preflight first. A smaller PowerShell preflight memory guard does not lower the browser guard. Existing automation Edge sessions must be cleared by their owner before starting a separate measurement; personal browsers must remain untouched.

Actual browser controls require real Chart.js and pako libraries. Offline regression placeholder assets intentionally do not initialize those globals and are rejected before measurement; do not reuse preflight placeholder output as a live browser control. Payload provenance is streamed through gzip validation and SHA-256 hashing, retaining compressed/decompressed byte counts and hashes without a full payload parse in Node. The retained HTML and immutable asset paths stay unchanged; only the current manifest-assembled dashboard runtime is served in place of the retained runtime script.

The harness requires at least 3 GiB free RAM before launch and throughout sampling, caps the owned Edge family at 2 GiB, and bounds readiness at 120 seconds. Inventory is asynchronous, single-flight, fail-closed, and starts before launch, then immediately after spawn before CDP polling. Every successful run must pass an awaited final resource sample. Caps, floor breaches, inventory exceptions, and other aborts immediately request bounded termination of only the spawned/profile-owned family. Cleanup attempts process termination, launcher exit, CDP/browser closure, final inventory, profile removal, and HTTP server closure independently. Unknown remaining process state is not zero or success. Original measurement errors remain separate from fixed cleanup failure labels; raw stacks, command lines, and profile paths are not evidence fields.

`ttiBrowserMs` records the first browser `dashboard-ready` event using `performance.now()` from navigation time origin; it is a readiness measure, not interaction latency. Host observation wall time and later snapshot time are separate. Memory samples carry host monotonic and epoch timestamps, with browser phase/message epoch timestamps for correlation. Phase observations and process working-set peaks are sampled, not instantaneous boundaries or proven absolute peaks. Heap scope is the main renderer only. Heap/readiness instrumentation adds measurement overhead. Worker return format labels distinguish phase messages, legacy arrays, row envelopes, and lookup/raw-column envelopes without changing the runtime payload contract.

Family private memory is also sampled, but the unchanged family cap applies to working set. Observational CDP heap/readiness probes are single-flight and may stall during main-thread work; they do not impose a separate five-second initialization deadline. Final probe drain is bounded to five seconds before cleanup proceeds; a drain timeout sets `incompleteHeapSample` rather than manufacturing a heap measurement or a resource-guard failure. The independent process inventory retains its own timeout and fail-closed guards. Scalar initialization traces fail promptly on a caught initialization error and retain only error class, function names, and source positions, never raw messages, stacks, or payload records. Worker markers are retained at the first valid readiness snapshot even if a later report/guard check fails. A partial readiness snapshot is not a passed run, and its `activeRows` means filtered source rows, not grouped active report rows.

Normalized counts must equal the explicit expectation and agree across cold/reload runs. Required report renders, impact/filtered-source counts, severity-card hashes, and `readinessCacheDigest` must agree; this is readiness/cache consistency, not report-content semantic validation. Equal zero counts alone do not establish report coverage. The explicit two-row `--positive-control` sets January 1-2, 2026 through the existing date popover, requires both source rows selected and exactly two grouped active rows, impact rows, and severity-card total for the committed fixture, and compares those observations across cold/reload. This avoids fixture dates falling outside today's default history window; it does not validate every grouped report field. The harness captures the runtime's actual compressed fingerprint once per navigation, requires the same key across cold/reload, and inspects its matching IndexedDB entry and the runtime's row/entry limits. Eligible reloads must actually hit cache; ineligible reloads are labelled `cachedEligible: false` with an explicit reason, never forced into the cached lane. There is currently no separate byte soft limit or cache feature flag. Production cache writes remain disabled at 500,000 rows and above. A passed mock, small control, or full preflight cannot establish a large-data performance result.

Profile ownership uses native Windows argument parsing, a single exact profile switch (equals or separate-value form), fully qualified path normalization, slash normalization and ordinal case-insensitive comparison. Prefix neighbors, literals inside other arguments, relative paths and duplicate profile switches are excluded. Descendant closure retains root creation provenance; fresh snapshots and process start identities are checked before each kill. No unchecked `taskkill /T` or launcher-PID kill is used. Windows browser-free probes run the actual PowerShell code against mocked process APIs, including surviving neighbors and root PID reuse; they never kill real processes. All command-entry and evidence-write failures emit fixed labels with allowlisted phase/reason/code fields, never raw messages, exception names, stacks, URLs, query keys, tokens or paths. Instrumentation retains only allowlisted function/phase names and numeric positions. Metric snapshots are copied so later mutations remain observable; absent optional instrumentation is tolerated.

Owned termination orders descendants before their roots and requires fresh process/root identity before a kill. An item with incomplete fresh creation-time or root-command-line evidence is skipped without calling `Get-Process` or `Kill`; only sanitized `processIdentity`, `rootCommandLine`, and `rootCreationDate` attempt counters are retained in `termination.skippedUnverified`. Every selected identity, including a child first discovered during termination, remains accountable until its own absence or PID reuse is verified. Final inventory accounts for same-identity children independently of root disappearance or root PID reuse; this accounting can conservatively retain descendants, but it never authorizes a kill. Unknown final owned identity fails closed and retains the profile. The ownership mocks cover both incomplete fields, no unverified kill, integrated orphan/root-reuse survivors failing cleanup, actual disappearance and own-PID reuse passing final inventory, descendant-before-root order, unexpected native kill failures, unknown live identities, and PID reuse. A failed termination leaves accounting incomplete for that owner instance: later inventory cannot claim zero or remove the profile. Final zero processes never erases an earlier operation failure. Actual acceptance requires a non-mock native cold/reload control with Node exit zero, no cleanup failures, profile removal, server closure, unchanged fixture hashes, and preserved unrelated process identities. These checks establish the exercised lifecycle and readiness/cache behavior only; they do not establish historical large-data performance.

## Hosted smoke diagnostics

The worker-transfer harness can also exercise the admin flow in its existing
owned browser. Set `DASHBOARD_BROWSER_ENGINE=chrome` for the installed Chrome
engine; the default remains Edge and a missing selected engine fails without
fallback. Engine executable SHA-256 and actual version are recorded. Use
`--generated-runtime` to measure the exact newly generated hosted runtime and
optional chunks, rather than the default source overlay.

Add `--admin-exercise` to measure filter completion, all five report switches,
all three report detail dialogs, PDF runtime/library loading and real PDF
preparation for representative and empty scopes. This uses one selected device
with at most 250 source rows for bounded PDFs while loading/filtering the full
input. It checks ten real PDF buffers and restores the original scope. It does
not establish visual readability or the final OS
download. Normal native ownership, resource, admission and outer-supervision
requirements still apply; do not run this option as an unguarded stress test.
Detail dialogs are opened through the actual delegated table-row click handlers.
Missing matching rows are labelled explicitly rather than assigned a latency.
The two device reports show details inline; that cost is included in report
switching and is not reported again as a separate dialog-opening measurement.
The representative filter must settle and pass the existing row cap before PDF
runtime/library loading starts; their separate timings record that selected
scope. Runtime/library failures still restore the original filter, report, mode
and warning state without assuming a download hook was loaded.

By default, both exercise lanes first tour all five reports at the original,
unfiltered scope. Add `--scoped-admin-first` with either `--admin-exercise` or
`--saved-artifacts` to run load → filter → scoped reports/detail/PDF → restore
immediately after the readiness snapshot, omitting that unfiltered tour. The
option cannot run alone. The workload label distinguishes the two sequences;
scoped-first runs retain `reportSwitches: []` and `readinessCacheDigest: null`,
and do not qualify unfiltered report switching. Their `reportIds`, `reportRows`
and representative `impactRows` come from the actual helper receipts. A separate
`scopedWorkloadSummary`/`scopedWorkloadDigest` compares source rows, grouped rows
and severity cards for every captured scope/report across cold/reload; it also
includes saved-artifact range modes and any admitted long-table scope. Existing
all-five representative/empty coverage, scope restoration, cache, native owner,
resource and cleanup checks remain required. This is a bounded scoped workflow,
not evidence that the unfiltered-tour stress workload passes.

For genuine self-contained acceptance, add `--self-contained --generated-runtime`
and supply a directory containing `VulnerabilityDashboard.html`. The harness
navigates to the exact retained `file://` URL, executes its actual inline runtime
and embedded libraries, and fingerprints its embedded compressed payload. It
does not substitute the source overlay or serve the page over HTTP. File requests
are restricted to that exact HTML file, optionally with its single persisted
`view` parameter; neighboring files, external URLs and arbitrary queries fail.
Hosted mode keeps its existing same-origin policy. Compare the payload identity
and DOM scope receipts across delivery modes; the embedded product has no
separate hosted summary asset.

Use `--date-range=2025-01-01/2026-10-22` for the retained 19,677-row synthetic
fixture, or `--positive-control` for the two-row January 1-2, 2026 fixture. The
chosen range is applied through the real date popover and recorded explicitly.
Do not infer a valid empty input or supported tenant maximum from these fixtures.

`--saved-artifacts` is a separate acceptance lane and cannot be combined with
`--admin-exercise` getBuffer timing. It retains the real `downloadPdfDocument`,
observes the browser download event, and saves actual PDFs with `saveAs` for
all five reports in representative and empty scopes, with snapshot mode selected
for the two device reports. Two additional representative PDFs select observed
range mode through the real device-report mode buttons. Each load captures twelve
PDFs plus viewport screenshots and JSON receipts of the exact expanded DOM,
table cells, report/filter/mode, source/grouped counts, cards and restoration.
Card receipts retain every title, visible metadata and stat badge, including
Platform, Patch and legacy Update references. Device receipts include the exact
UI mode summary and resolved-inclusion label; mode-button transitions are
recorded separately from already-selected controls. Compare all these fields
against actual PDF text; matching receipts alone do not establish PDF parity.
The saved-artifact lane prepares the PDF runtime only after the selected device
scope passes the same row cap. PDF libraries load through the actual Export PDF
button; there is no eager unfiltered library preload in this lane.
One additional Active Vulnerabilities PDF is captured only when a selected
subset of at most 250 source rows actually yields more than 100 grouped report
rows. Unavailable long-table coverage is labelled; no row or resource bound is
raised. Screenshots use a fixed 1440 by 1000 viewport. Each artifact is capped
at 64 MiB and each expanded report text receipt at 500,000 characters.

Use a fresh evidence JSON path outside the retained product directory. Artifacts
are saved beside it under `<evidence-path>.artifacts/iteration-<n>-<first|reload>`.
Individual files are **pending** until the containing run passes all scope,
resource, download, restoration and native cleanup checks. Hashes and PDF
header/EOF validation establish file identity/completeness, not semantic or
visual acceptance: extract PDF text and compare the selected filters, table
content and totals with the receipts, then render and inspect the PDF pages.
Viewport screenshots alone do not establish long-table PDF pagination quality.
The saved-artifact lane also exercises real facet pill/checkbox/Apply events,
explicit severity selection and individual deselection to None. It checks the
group/platform hidden-selection intersection using two existing devices with
distinct groups and platforms when available, or the existing global facets;
otherwise that case is labelled unavailable. Report changes use the visible
report popover and PDFs use the actual Export PDF button. Fixture planning and
final restoration still use read-only inspection and the saved state API; this
bounded event exercise does not claim coverage of every UI interaction.
Keep these synthetic artifacts private; do not use the content-capture option
with live tenant data. Use one pinned common harness for both product revisions
and identical engine/runtime/input/library bytes for comparisons. The existing
outer supervisor, admission samples and native ownership gates remain required.

Browser-free controls run as part of the existing measurement/telemetry mock
lane, and can be run alone with `node tests/Assert-DashboardArtifactAcceptance.js`.
They exercise exact file URL scope, retained inline identity, operation deadlines,
download-event ordering/failure, truncated PDF rejection and invalid receipts;
they do not launch a browser or establish download/visual acceptance.

Add `--progress-journal` to retain bounded stage/memory samples beside the
evidence JSON when an outer supervisor terminates the process before its final
write. Its parent directory must already exist outside the retained product.
The fresh version-2 journal is capped at 2 MiB and contains input fingerprints,
existing guard samples, separate Node RSS/heap/external counters, and bounded
browser main-heap/initialization/worker observations. Opt-in console checkpoints
retain initialization and worker delivery even if final measurement JSON is
never written. The `--admin-exercise` timing lane additionally records per-action
filter/library/detail/PDF boundaries, including header capture versus buffer
generation and exact bounded source/report row counts before export. The
saved-artifact lane does not yet record those per-action checkpoints. Only allowlisted
names, states and numeric observations are retained; row contents and arbitrary
console text are excluded. Missing observations are not evidence that a phase
did not execute. Node RSS, browser-family working set and the outer all-descendant
working-set cap remain distinct; do not subtract asynchronous samples as exact
per-process attribution. It is partial diagnostic evidence, never proof of run
completion or cleanup. Use the same setting for both sides of a comparison.

Compressed worker replies transfer inflated UTF-8 bytes and terminate the worker
before main-thread decoding/parsing and row construction. The compressed input
remains available for fallback; payload schema and cache eligibility are unchanged.
Observe `workerInflateMs`, `workerDeliveryMs`, `mainDecodeMs` and `mainParseMs`;
`workerParseMs` is absent on this route. Parsing moves to main rather than
disappearing, so assess whole initialization latency and native memory together.
`Assert-DashboardWorkerBufferTransfer.js` exercises real worker transfer/detachment,
native gzip and the pako-compatible view path, Unicode/BOM, matrix/columnar/empty
full-field parity and failure fallback with retained compressed bytes. These tiny
controls do not establish representative browser performance.

`Assert-DashboardRowShapeParity.js` compares every row field against the pinned
`77d672bbf682351b35773ce80bcf4d83341c5f3b` oracle, excluding only the internal
`_issueKey` scratch property. It covers matrix/columnar input, equivalent lookup
identities, skipped raw indexes, numeric-zero and overflow keys, cold/worker/warm
paths, legacy scratch cleanup and materialized detail fields. New rows reserve
their final environment-first-seen date directly and retain no issue scratch;
these small controls establish semantic parity, not a browser memory benefit.

Opt-in progress journals also write a host-side `report-switch` start before each
unfiltered report call, then completion or failure after its existing guarded
readiness wait. This identifies the in-flight report when the containing owner
terminates the browser before final results can be written. The fixed record
contains only allowlisted report/state values and existing numeric snapshots;
`observationScope` explicitly marks prior counts and sampled run-peak heap, not
fresh per-report counts or current memory. It performs no extra browser queries,
row scans, materialization, DOM traversal or native inventories. Action clocks
exclude journal writes. `Assert-DashboardReportSwitchDiagnostics.js` checks actual
helper ordering, genuine failures, unchanged call semantics, opt-out, privacy and
fail-closed journal errors. This diagnostic was added after the campaign; it has
not identified the full-data bottleneck in a live run.

Run the isolated two-row Hosted dashboard control, generated from synthetic data without root exports, authentication, or cloud writes:

```powershell
pwsh -NoProfile -File .\tests\Invoke-HostedDashboardRuntimeSmoke.ps1 -ControlFixture
pwsh -NoProfile -File .\tests\Invoke-HostedSmokeDiagnosticsRegression.ps1
```

The control copies the committed two-row synthetic legacy fixture into temporary storage and generates Hosted output through the normal generator with machine export disabled. The browser smoke first runs a JavaScript canary, then the real dashboard readiness/report-switching/filter-popover probe, sequentially with the same unique temporary Edge profile. An existing extension/automation Edge session blocks new launches; personal browsers are never terminated. Arguments use .NET `ProcessStartInfo.ArgumentList`, including profile paths containing spaces. An exit code of zero with empty or whitespace DOM is a failure, not a pass or skip. Probe state, phase, reason, and class (`timeout`, `assertion`, `operation`, or `none`) are allowlisted enums, never literal DOM, exception types, or error messages. Markers are assigned before readiness, payload, inflate, count, report-switch, and filter-popover operations; setup failures retain fixed phase/class labels and a source line number.

Every started run retains sanitized diagnostics, on failure and success, in ignored `.local/hosted-smoke-diagnostics/hosted-smoke-<UTC timestamp>-<random ID>/`. `-DiagnosticsPath <directory>` selects a caller-owned root using the same deterministic prefix; keep that root private and out of version control. Errors print only the run ID and fixed outcome. `run.json` records outcome and cleanup; `canary.json` and `dashboard.json` retain exit codes, byte counts, capture limits, conventional scrubbed flags, and fixed states. Sibling `*.stderr.sanitized.log` files contain at most 128 category/redacted-example/SHA-256 records. Recognized Chromium sources map to fixed categories; unknown lines are hashed, never copied. No raw stderr examples, URLs, user paths, project metadata, DOM, stdout, or profile content is retained in these artifacts.

Streams drain concurrently in memory: stdout retains at most 64 MiB for assertions; stderr retains at most 64 KiB for sanitization while byte counting continues. Truncated DOM or incomplete drains fail. Process enumeration/termination, server stop/wait/removal, profile removal, site removal, and final diagnostic write are independently guarded. `run.json` retains `originalOutcome`, `processCleanupConfirmed`, and fixed `cleanupFailures`; unknown process state is not a clean result. Diagnostic write failure emits only `diagnostic-write-failure`; when the destination is unavailable, the final record cannot be retained. Cleanup never replaces a pending original exception, and success is emitted only after cleanup. The PowerShell regression exercises the actual helper and extracted entire `finally`, including a real missing-directory provider write. The extracted-probe JavaScript regression uses a virtual clock to distinguish readiness timeout from payload assertion and operation failures. SHA-256 records are fingerprints, not reversible examples, but low-entropy text can still be guessed; treat diagnostics as private. Raw captured text is transient managed memory, not guaranteed cryptographically erased.

`headless-control-failure` means the canary failed too; `dashboard-probe-failure` means the canary passed but the dashboard did not; `command-forwarding-suspected` requires recognized forwarding stderr. A missing forwarding hint does not rule forwarding out. These controls diagnose an empty-DOM environment; they do not turn a blocked browser launch into a dashboard pass. The browser-free injected-process/privacy regression is part of deterministic preflight; actual Edge remains a separate optional Windows gate.

## CI-aligned live dry run

Run the exact live export and dashboard-generation path locally against your current Az context with:

```powershell
pwsh -NoProfile -File .\build\Invoke-LiveDashboardDryRun.ps1 -UseExistingAzContext
```

Defaults:
- output root: `.local/local-reports/live-dashboard-dry-run/`
- includes Advanced Hunting by default
- writes `dashboard-audit.json` and `dashboard-live-run-manifest.json` alongside the generated HTML

Use `-UseRepositoryOutputPaths` only when you intentionally want the live dry run to write into the ignored local `exports/` and `VulnerabilityDashboard.html` paths. Keep all live outputs private and out of logs and PR evidence.

## Legacy migration fixture

`tests/fixtures/legacy-migration` contains a tiny synthetic dataset used to exercise the temporary legacy vulnerability migration path.

Important note:
- the fixture files named `*.json` are intentionally a mix of formats
- `VulnExport_*.json` and `AdvancedHunting_Current.json` are NDJSON-style files, where each line is an individual JSON object
- `Machines_Current.json` is a single JSON object

These shapes match what the pipeline readers already support, even though NDJSON files are not a single valid JSON document when opened in a generic JSON validator.

The fixture smoke runs in `build/Invoke-RegressionValidation.ps1` and the legacy fixture regression path both execute against temp copies so derived `.dashboard-cache/` output does not pollute the committed fixture.

Automated regression checks do not require root `exports/`, a generated root dashboard, or report PDFs. Cardinality fallback uses a temporary one-device/one-template dictionary without a synthetic manifest. Procedural ordering keeps two fresh-process 12-device/300-row runs; semantic replay keeps 50 devices/5,000 observations. Hot-phase smoke generates a pinned 16-device/240-observation dataset (seed 4242, date 2026-07-11) in temp storage. All temporary datasets and dashboards are cleaned up after the checks.

## Large synthetic stress dataset

Generate a large helper-compatible export set locally with:

```powershell
pwsh -NoProfile -File .\tests\Generate-SyntheticLargeExports.ps1
```

Defaults:
- preset: `BalancedMediumHeavy`
- target devices: `20,000`
- target vulnerability rows: `1,500,000`
- output path: `.\exports-synthetic`

The procedural generator defaults `-SourcePath` to `tests/`, an existing neutral directory; it does not read source exports. Use an explicit synthetic fixture path with `-UseLegacyGenerator`, which does read its source. Benchmark workload definitions also use the neutral `tests/` directory. Memory and disk guards for large workloads remain enabled.

Run an iterative local dashboard generation against that synthetic export set with:

```powershell
pwsh -NoProfile -File .\tests\Invoke-LargeDatasetValidation.ps1 -Validate -ValidationMode artifacts
```

That command:
- regenerates the synthetic exports
- runs `Generate-VulnerabilityDashboard.ps1` against them
- validates the generated self-contained and hosted dashboard artifacts
- writes `synthetic-manifest.json` and `stress-validation-report.json` under `exports-synthetic/`

Reserve the semantic replay for milestone or final local sign-off:

```powershell
pwsh -NoProfile -File .\tests\Invoke-LargeDatasetValidation.ps1 -Validate -ValidationMode semantic -ForceFullValidation
```

That semantic mode additionally writes `dashboard-audit.json` under `exports-synthetic/` and forces a fresh full semantic replay instead of reusing an attested validation sidecar.

Supported presets:
- `DeviceCardinalityFirst`
- `BalancedMediumHeavy`
- `CurrentDensity`

## Synthetic live export

Create a shifted synthetic dataset that preserves the original export shape while moving the latest observation date forward:

```powershell
pwsh -NoProfile -File .\tests\New-SyntheticLiveExport.ps1 -SkipContentStoreSidecars
```

Defaults:
- source path: `.\exports-synthetic`
- output path: `.\exports-synthetic-live`
- target latest date: current UTC date

`-SkipContentStoreSidecars` keeps the output in raw-export form so downstream validation paths can rebuild sidecars on demand.

## Large import coverage

Large-dataset review now needs three separate lanes. Do not rely on completed, content-store-ready datasets alone.

### One-command workflow

Use this entrypoint when you want the synthetic import lane prepared and locally checked end to end with one command:

```powershell
pwsh -NoProfile -File .\tests\Invoke-LargeImportCoverage.ps1
```

By default this workflow:
- generates a raw synthetic dataset with canonical current/history row files
- shifts that dataset forward to a live date without rebuilding content-store sidecars
- materializes deterministic legacy `VulnExport_<group>_<date>.json.gz` files from the raw live dataset
- builds `.local\large-import-coverage\azure-replay-existing-exports` with `Machines_Current.json.gz`, `AdvancedHunting_Current.json.gz`, and the synthetic legacy vulnerability snapshots for `UseExistingExportsOnly=true` Azure replay runs
- runs local raw replay validation and local legacy vulnerability import validation unless you explicitly skip them

Useful switches:
- `-SkipRawValidation` while iterating on dataset prep only
- `-SkipLegacyImportValidation` when you only need the replay dataset artifacts
- `-SnapshotCount <n>` or `-SnapshotDates <yyyy-MM-dd,...>` to control which synthetic legacy snapshot dates are emitted
- `-AllowLargeDataset` for unattended large captures beyond the default safety limits

### Bounded Fresh-Import Profiling

`Invoke-LargeImportCoverage.ps1 -ProfileFreshImport` adds test-only scalar operation timing and current-thread allocation attribution to the real snapshot publisher. It requires procedural synthetic/reference manifests and a new import directory, creates an unprofiled twin, compares every decompressed store output, and checks current IDs against the authoritative onboarded reference projection. Functions are instrumented only in memory and restored in `finally`; production defaults are unchanged. Profiling overhead is included, nested measurements must not be summed, and this is not a cloud memory/performance acceptance run.

Example with neutral test input and bounded pinned generation controls:

```powershell
$root = Join-Path $PWD '.local/issue67-profile'
& ./tests/Invoke-LargeImportCoverage.ps1 `
  -SourcePath ./tests -TargetDeviceCount 50 -TargetTotalVulnRows 5000 `
  -ContentTemplateCount 5000 -Seed 20260322 -GenerationDate 2026-09-29 `
  -MinimumAvailableMemoryGB 1 -MinimumFreeDiskGB 1 `
  -TargetLatestDate 2026-09-30 -SnapshotDates @('2026-09-29','2026-09-30') `
  -RawSyntheticOutputPath (Join-Path $root 'reference') `
  -RawLiveOutputPath (Join-Path $root 'overlay') `
  -LegacySnapshotOutputPath (Join-Path $root 'snapshots') `
  -LegacyImportValidationPath (Join-Path $root 'profiled') `
  -SkipAzureReplayDatasetBuild -SkipRawValidation -ProfileFreshImport
```

Use a new output root for each capture. To retain a reference across captures, generate it once with `Generate-SyntheticLargeExports.ps1` and use `-SkipSyntheticGeneration`; reference generation and snapshot materialization are outside the timed import. The measured issue-67 samples explicitly used two procedural reference snapshots, while this composite example preserves the generator's existing default snapshot count. Keep all raw synthetic files and evidence under ignored local paths. See `docs/performance-baselines.md` for the measured baseline, exact controls and limitations.

### 1. Replay a completed dataset

Use this lane for steady-state normalization, packaging, and dashboard generation against a fully prepared export set.

Examples:

```powershell
pwsh -NoProfile -File .\tests\Measure-RunbookOnlyAzureBenchmark.ps1

$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
pwsh -NoProfile -File .\tests\Measure-BranchVsMainBenchmark.ps1 -CurrentOnly -DatasetPath .\exports-synthetic-live -ResultsOutputPath (Join-Path $PWD ('.local\current-baseline-live-' + $stamp + '.json'))
```

### 2. Replay a raw large dataset without sidecars

Use this lane when you want to catch hot paths hidden by already-materialized content-store artifacts. This is the preferred synthetic path for large import-like validation of Machines, Advanced Hunting, and canonical vulnerability current/history rows.

Recommended workflow:

```powershell
pwsh -NoProfile -File .\tests\Generate-SyntheticLargeExports.ps1 -OutputPath .\.local\large-datasets\synthetic-raw -IncludeRawRows -AllowLargeDataset

pwsh -NoProfile -File .\tests\New-SyntheticLiveExport.ps1 -SourcePath .\.local\large-datasets\synthetic-raw -OutputPath .\.local\large-datasets\synthetic-raw-live -SkipContentStoreSidecars -Force

pwsh -NoProfile -File .\tests\Invoke-LargeDatasetValidation.ps1 -SkipSyntheticGeneration -SyntheticOutputPath .\.local\large-datasets\synthetic-raw-live -Validate -ValidationMode artifacts
```

Switch that final command to `-ValidationMode semantic -ForceFullValidation` only when you need the full streaming semantic replay before sign-off.

Standalone legacy vulnerability snapshot materialization from that raw live dataset:

```powershell
pwsh -NoProfile -File .\tests\New-SyntheticLegacyVulnSnapshotSet.ps1 -SourcePath .\.local\large-datasets\synthetic-raw-live -OutputPath .\.local\large-datasets\synthetic-legacy-vuln -SnapshotCount 2 -Force
```

If you need Azure replay against that raw dataset, prefer the composite dataset produced by `Invoke-LargeImportCoverage.ps1` under `.local\large-import-coverage\azure-replay-existing-exports`, then seed that path into storage before starting `Measure-RunbookOnlyAzureBenchmark.ps1` or `Measure-BranchVsMainBenchmark.ps1` with `UseExistingExportsOnly=true`.

### 3. Run a live fresh-export Azure Automation job

Use this lane to exercise the real Stage C import path, including bulk vulnerability snapshot download, machine export refresh, and Advanced Hunting export refresh. This is the only supported large-scale path for fresh vulnerability snapshot import today.

Example:

```powershell
pwsh -NoProfile -File .\tests\Measure-RunbookOnlyAzureBenchmark.ps1 -UseExistingExportsOnly:$false
```

Important notes:
- `Measure-RunbookOnlyAzureBenchmark.ps1` defaults to `UseExistingExportsOnly = true` unless you explicitly pass `-UseExistingExportsOnly:$false`.
- `New-SyntheticLiveExport.ps1 -SkipContentStoreSidecars` forces sidecar rebuild and canonical raw-row replay, but it does not generate large synthetic legacy `VulnExport_*.json` snapshot sets.
- Large fresh vulnerability snapshot import is therefore validated today through live Azure Automation runs, not through a fully synthetic legacy-snapshot replay.

Recommended acceptance process for large import changes:
- one replay benchmark against a completed dataset
- one replay benchmark against a raw sidecar-free synthetic dataset
- one live Azure Automation fresh-export run
- record which lane each captured result belongs to so replay and fresh-import numbers are not compared as if they covered the same path

## Bounded Azure acceptance

For a final large-data acceptance run, use the guarded validation harness rather than invoking a runbook job manually. It backs up the published runbook and the `exports`/`dashboards` containers, deploys the generated candidate, seeds the selected dataset, downloads the published dashboard, verifies required artifacts and counts, performs source-to-dashboard parity, and restores the previous state in `finally` cleanup. Every Azure CLI operation must target the intended subscription explicitly.

Candidate deployment and restoration send the file's raw bytes to the ARM runbook draft-content endpoint (`2023-11-01`, `text/powershell`), then publish. This preserves CRLF/LF, UTF-8 BOMs, and trailing newlines that CLI text ingestion can normalize. Restoration downloads the published content and checks its SHA-256 against the backup, along with every export/dashboard file's bytes and hash. `-FailureInjectionPoint AfterDeploy -ExpectedTotalRows 1 -Execute -Confirm:$false` exercises backup, deployment, and restoration without seeding exports or starting a runbook job; the injected error is expected only when restoration evidence also matches.

Example for the prepared generated 50K raw replay seed (the raw replay lane publishes 1,187,395 onboarded rows):

Count preflight accepts only an explicitly supplied `-ExpectedTotalRows` or authoritative numeric `expectedDashboardRows` in `synthetic-manifest.json` (for example, `"expectedDashboardRows": 1187395`). Counts must be whole numbers from 1 through 50,000,000. An explicit parameter takes priority, even when manifest metadata is malformed or has the wrong type. `actualTotalVulnRows` and `actualCurrentRows` count source observations, not onboarded normalized dashboard rows, and are never inferred as the expectation. Observation-only manifests, including existing generated datasets, require the parameter; determine it from a verified projection for the exact dataset and replay lane, not device ratios. Missing or invalid expectations fail before output/lock creation or Azure calls; preflight does not normalize the dataset.

```powershell
pwsh -NoProfile -File .\tests\Invoke-AzureRunbookValidation.ps1 `
  -SubscriptionId '43babb60-9e73-4dc8-b769-4401c01aad73' `
  -AutomationAccountName 'aa-defender-reporting' `
  -AutomationResourceGroup 'rg-defender-reporting' `
  -RunbookName 'Invoke-DashboardPipeline' `
  -StorageAccountName 'stdefenderrepaad73' `
  -DatasetPath .\.local\fast-large-import `
  -SeedMode ContentReplay `
  -DashboardDeliveryMode Hosted `
  -ExpectedTotalRows 1187395 `
  -UseExistingExportsOnly `
  -ValidatePublishedSemanticParity `
  -Execute -Confirm:$false
```

The harness uses exact decompressed payload bytes for the high-cardinality compiled path. For modest compatibility workloads, enrichment lookup insertion order may legitimately change the serialized bytes, so parity falls back to canonical expanded-row equivalence. A successful acceptance must still have zero missing and zero extra rows, valid current/history/dictionary/ref artifacts, and a true pre-trim working-set peak below the 400 MB Automation ceiling. The status evidence records working set, private memory, GC heap, phase, row count, and compiled telemetry; keep the timestamped result under `.local\azure-validation\`.

Compatibility gates use synthetic enrichment regressions and temporary copies of the minimal legacy fixtures, not checked-in live exports. When changing enrichment or machine lookup code, retain coverage for Advanced Hunting CVE/device-user/inventory data, NVD data, scalar and array machine tags, Unicode, and optional properties; a content-only synthetic dataset alone is insufficient.

When the Function App is the isolated subject of a test, add `-SkipAutomationValidation` to the build validation command. The default still validates both compute paths; the switch only avoids running the paired Automation deployment/validation while preserving Function App deployment, seeding, execution, status polling, and temporary-setting cleanup.

## Hot phase review

Review the local generator and validation hot phases with:

```powershell
pwsh -NoProfile -File .\tests\Invoke-HotPhaseReview.ps1 -DirectoryPath .\exports
```

That command:
- runs `Generate-VulnerabilityDashboard.ps1` with validation enabled
- captures local process memory samples plus the generator stdout and stderr logs
- parses the local phase markers emitted by `Generate-VulnerabilityDashboard.ps1`
- extracts the audit `PhaseTimings` block for any validation mode and falls back to `SemanticParity.PhaseTimings` for older audit shapes
- writes `hot-phase-review.json` under `.local/hot-phase-review/<timestamp>/`

Long-running review, stress, and benchmark wrappers now emit timestamped heartbeat lines at their poll interval so you can confirm they are still making progress even when the child process is temporarily quiet.

Use a smaller synthetic dataset while iterating, then move to the benchmark and Azure validation entrypoints once the local hot phases improve.

## Routine semantic review

Run the routine medium-dataset semantic lane with:

```powershell
pwsh -NoProfile -File .\tests\Invoke-RoutineSemanticReview.ps1
```

That command:
- ensures the durable `benchmark-medium-v1` dataset is present
- runs `Invoke-HotPhaseReview.ps1` against that dataset in `semantic` mode with `-ForceFullValidation`
- writes the review artifacts under `.local\routine-semantic-review\<timestamp>\`
- gives you a repeatable semantic review path that is materially cheaper than the `synthetic-50k-1_5m` full sign-off lane

Use this workflow for routine semantic or validation review during iteration, then keep the full `synthetic-50k-1_5m` semantic gate for release sign-off and high-risk normalization changes.

## Hosted dashboard runtime smoke

Run the hosted dashboard through a non-visual Edge smoke when split-assets delivery changes or when you want an explicit browser-runtime check:

```powershell
pwsh -NoProfile -File .\tests\Invoke-HostedDashboardRuntimeSmoke.ps1 -DashboardPath <hosted-html-path>
```

Notes:
- this lane requires Windows and Microsoft Edge
- use `-AllowSkip` when you want optional local coverage on machines without Edge
- pair it with `build/Invoke-RegressionValidation.ps1`; it supplements the deterministic gate instead of replacing it

## Validation mode comparison

Split packaging, full validation, and attested validation into separate measured runs with:

```powershell
pwsh -NoProfile -File .\tests\Invoke-ValidationModeComparison.ps1 -DirectoryPath .\exports
```

That command:
- warms a reusable normalized payload artifact with `-NormalizeOnly`
- measures `-PackageOnly` against that payload artifact
- measures `-ValidateOnly -ForceFullValidation` and the attested `-ValidateOnly` fast path against the same packaged dashboard
- measures end-to-end `-Validate -ForceFullValidation` and the default `-Validate` path
- writes `validation-mode-comparison.json` under `.local/validation-mode-comparison/<timestamp>/`

Use this workflow when validation is the dominant hot phase and you need to distinguish package cost from semantic replay cost.

## Benchmark and stress tool selection

| Goal | Preferred entrypoint | Notes |
| --- | --- | --- |
| One-command repeated local benchmark on the durable dataset | `tests/Invoke-BenchmarkSeries.ps1` | Use when refreshing or comparing repeatable local baselines |
| Current branch vs. main or a one-off branch capture | `tests/Measure-BranchVsMainBenchmark.ps1` | Best for side-by-side local comparison |
| Phase-by-phase local review | `tests/Invoke-HotPhaseReview.ps1` | Start here before heavier benchmark or Azure work |
| Medium-dataset semantic validation during iteration | `tests/Invoke-RoutineSemanticReview.ps1` | Preferred semantic lane for routine branch work |
| Validation cost split between packaging and semantic replay | `tests/Invoke-ValidationModeComparison.ps1` | Use when validation time dominates |
| Custom stress capture | `tests/Measure-StressRun.ps1` | Reserve for targeted stress investigation, not routine branch validation |

## Benchmarking

Create or refresh the durable benchmark dataset with:

```powershell
pwsh -NoProfile -File .\tests\New-BenchmarkDataset.ps1 -DatasetId benchmark-medium-v1
```

That dataset definition currently maps to:
- dataset id: `benchmark-medium-v1`
- preset: `BalancedMediumHeavy`
- target devices: `1,500`
- target vulnerability rows: `120,000`
- seed: `20260322`
- output path: `.local\benchmark-datasets\benchmark-medium-v1`

For the larger reusable Azure stress seed, materialize or register the existing 50k-device dataset with:

```powershell
pwsh -NoProfile -File .\tests\New-BenchmarkDataset.ps1 -DatasetId benchmark-large-50k-v1 -AllowLargeDataset
```

Benchmark seeds now use the deterministic `procedural-v1` model and compiled streaming writer by default. The seed, model version, cardinalities, generation date, churn, and sparsity settings are recorded in `synthetic-manifest.json`; repeat runs with the same settings produce byte-stable gzip data artifacts.

The procedural writer is intentionally streaming: it derives devices, templates, observations, and edge cases from `seed + ordinal + snapshot`, writes JSON/gzip artifacts directly through the embedded writer, and avoids a global source-row or signature cache. Use `-GenerationDate`, `-SnapshotCount`, `-ChurnRate`, `-ContentTemplateCount`, and `-OptionalFieldSparsity` to vary a reproducible dataset without changing the public entrypoint. Keep `-UseLegacyGenerator` only for comparison runs; it is not the bounded-memory acceptance path.

That dataset definition maps to:
- dataset id: `benchmark-large-50k-v1`
- preset: `BalancedMediumHeavy`
- target devices: `50,000`
- target vulnerability rows: `1,500,000`
- seed: `20260322`
- output path: `.local\large-datasets\synthetic-50k-1_5m`

Each generated benchmark dataset now records durable breadth counters in both `synthetic-manifest.json` and `benchmark-dataset.json`:
- `uniqueCveIdCount`: distinct raw `CveId` values present in the compact content dictionary
- `normalizedCveLookupCount`: distinct normalized CVE lookup entries (`CveId` + score/severity/exploitability/url/title), which is the same breadth surfaced as `CVEs` in dashboard and Azure acceptance summaries
- `contentTemplateCount`: distinct compact vulnerability content templates in the dataset

Use those counters when you need to compare regenerated benchmark breadth over time without unpacking the dataset by hand.

When you want to keep the large seed current and exercise the vulnerability-store merge path without regenerating 1.5M rows, create a shifted current-snapshot delta overlay with:

```powershell
pwsh -NoProfile -File .\tests\New-SyntheticSnapshotDelta.ps1 -SourcePath .\.local\large-datasets\synthetic-50k-1_5m -OutputPath .\.local\large-datasets\synthetic-50k-1_5m-delta-<date> -TargetLatestDate <yyyy-MM-dd>
```

That command:
- reuses the large canonical store as the base seed instead of rebuilding it
- writes a fresh `Machines_Current.json.gz` with shifted observation dates
- writes a new `VulnExport_<group>_<date>.json.gz` snapshot representing the next full bulk export date
- is intended for Azure replay paths that merge incoming snapshots into the existing canonical store
- defaults to `AdvanceSnapshot`, which hard-links unchanged seed artifacts and procedurally writes only `Machines_Current.json.gz`, new grouped `VulnExport_*_<date>.json.gz` snapshots, and overlay metadata
- supports `-Mode ShiftAllDates` for legacy datasets that do not contain `procedural-v1` model metadata

Capture a repeatable multi-run benchmark series against the standard dataset with:

```powershell
pwsh -NoProfile -File .\tests\Invoke-BenchmarkSeries.ps1 -BenchmarkDatasetId benchmark-medium-v1 -Iterations 3 -IncludePersistentLocalWorkflow
```

That command:
- ensures the durable benchmark dataset exists
- records each benchmark JSON under `.local\benchmark-series\`
- appends each run to `.local\benchmark-history\benchmark-history.jsonl`
- writes aggregate `series-summary.json` and `series-summary.md` artifacts

`Measure-BranchVsMainBenchmark.ps1` and `Invoke-BenchmarkSeries.ps1` default to Azure-only capture. Add `-IncludeLocalBenchmark` when you also want local timings in the same run, or `-LocalOnly` when you want to skip Azure entirely.

For branch-vs-main captures, `Measure-BranchVsMainBenchmark.ps1` now records both the requested and effective baseline execution order plus `comparison.delta_basis = current-minus-main`.

- `-BaselineExecutionOrder Alternate` (default) flips who runs first across repeated captures so one branch is not always measured first.
- `-BaselineExecutionOrder CurrentThenMain` always runs the current branch first.
- `-BaselineExecutionOrder MainThenCurrent` always runs main first.
- Negative elapsed or memory deltas favor the current branch; positive deltas mean the branch was slower or used more memory.

Function App timing semantics:
- `function_app.elapsed_seconds` now tracks active execution time when the runtime status blob is available
- `function_app.end_to_end_elapsed_seconds` retains invoke-to-finish timing for queue and cold-start review
- `function_app.pickup_delay_seconds` records the gap between admin invocation and active execution start

Capture a current-branch-only benchmark baseline with:

```powershell
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
pwsh -NoProfile -File .\tests\Measure-BranchVsMainBenchmark.ps1 -CurrentOnly -CurrentBaselineName 'current-live' -DatasetPath .\exports-synthetic-live -ResultsOutputPath (Join-Path $PWD ('.local\current-baseline-live-' + $stamp + '.json'))

pwsh -NoProfile -File .\tests\Measure-BranchVsMainBenchmark.ps1 -CurrentOnly -IncludeLocalBenchmark -CurrentBaselineName 'current-live-with-local' -DatasetPath .\exports-synthetic-live -ResultsOutputPath (Join-Path $PWD ('.local\current-baseline-live-with-local-' + $stamp + '.json'))
```

Append a normalized local history entry after a benchmark completes with:

```powershell
pwsh -NoProfile -File .\tests\Record-BenchmarkHistory.ps1 -BenchmarkResultPath .\.local\current-baseline-live-<timestamp>.json
```

Recommendations:
- keep raw benchmark outputs under `.local/`
- use `.local\benchmark-history\benchmark-history.jsonl` plus `.local\benchmark-history\latest-summary.md` for repeated review and Azure acceptance captures that you want to compare over time
- prefer `benchmark-medium-v1` plus `Invoke-BenchmarkSeries.ps1` when you need the durable, merge-tracked benchmark cadence instead of an ad hoc review capture
- prefer `benchmark-medium-v1` plus `Invoke-RoutineSemanticReview.ps1` when you need repeatable semantic review coverage without paying for the 50k/1.5m local replay
- prefer `benchmark-large-50k-v1` plus `New-SyntheticSnapshotDelta.ps1` when you need a reusable large Azure seed with a fresh incoming snapshot date
- use the staged local copy behavior in `Measure-BranchVsMainBenchmark.ps1` when benchmarking raw datasets without sidecars
- use `docs/performance-baselines.md` only for accepted durable datasets that should remain merge-tracked as baseline documentation

## Explicit launch-bound native qualification

These Windows-only synthetic controls exercise `helpers/LaunchBoundJob.cs` with a
GUI-subsystem fixture and a real PowerShell owner. They do not qualify Edge,
IndexedDB, large datasets, tenant behavior, or arbitrary PowerShell descendant
provenance. Unexpected job members always fail identity validation. Failed
profiles and diagnostic artifacts must be retained.

Node launches a fixed PowerShell bootstrap which starts the real owner with
three restricted inherited pipe duplicates and no breakaway flag. This avoids
libuv's extra immediate-job policy while retaining the real owner's strict
supervisor-policy checks. The bootstrap reports the owner identity from its
original handle before protocol activation; the real owner waits for a private
client ACK and its readiness must corroborate that identity. Startup pipe EOF
exits the running owner gate rather than leaving a suspended helper behind.
No detached PowerShell launch, named outer job, or runtime startup hook is used.
Bootstrap compilation and owner startup share the existing readiness budget.
The native Node cases distinguish normal completion, actual real-owner crash,
bootstrap crash and client EOF. Read-only original handles cover the real owner
and both fixture descendants. A separate synthetic crash control rejects a
wrong creation identity before terminating the validated original owner handle.
An abrupt Node-parent-death experiment remains separate from explicit pipe EOF.

Use already installed PowerShell 7.6+, Node.js, .NET SDK 10.0.401, and the x64
reference/apphost/Core runtime packs 10.0.12. The fixture disables runtime
roll-forward. Missing versions are a prerequisite failure; these tests do not
install or download tools. The build clears package feeds and isolates caches,
SDK imports and environment variables. Keep generated bindings and raw evidence
in a private directory outside the tracked source.

Before building, create a private JSON toolchain binding with `schema: 1`,
`sdkVersion: "10.0.401"`, `runtimeVersion: "10.0.12"`, absolute `dotnetRoot`,
`dotnet`, `runtimeDirectory`, `dotnetSha256`, and a `groups` array. The groups
cover the complete installed SDK, reference pack, apphost pack, Core runtime,
and host/fxr directory. Each group has an `id`, absolute `root`, and every file
as `{path, bytes, sha256}` using relative forward-slash paths and lowercase
SHA256. Generate that inventory from the selected installed files, for example:

```powershell
# Run in PowerShell 7.6+. Select and review the local installation first.
$dotnetRoot = Join-Path $env:ProgramFiles 'dotnet'
$roots = [ordered]@{
    sdk = 'sdk/10.0.401'
    reference = 'packs/Microsoft.NETCore.App.Ref/10.0.12'
    apphost = 'packs/Microsoft.NETCore.App.Host.win-x64/10.0.12'
    runtime = 'shared/Microsoft.NETCore.App/10.0.12'
    hostfxr = 'host/fxr'
}
$groups = @(foreach ($id in $roots.Keys) {
    $root = Join-Path $dotnetRoot $roots[$id]
    $files = @(Get-ChildItem -LiteralPath $root -Recurse -Force -File |
        Sort-Object FullName -CaseSensitive | ForEach-Object {
            [ordered]@{
                path = [IO.Path]::GetRelativePath($root, $_.FullName).Replace('\', '/')
                bytes = $_.Length
                sha256 = (Get-FileHash -LiteralPath $_.FullName).Hash.ToLowerInvariant()
            }
        })
    if (-not $files.Count) { throw 'Installed toolchain group is missing.' }
    [ordered]@{id = $id; root = $root; files = $files}
})
$dotnet = Join-Path $dotnetRoot 'dotnet.exe'
$binding = [ordered]@{
    schema = 1; kind = 'toolchain'; sdkVersion = '10.0.401'; runtimeVersion = '10.0.12'
    dotnetRoot = $dotnetRoot; dotnet = $dotnet
    dotnetSha256 = (Get-FileHash -LiteralPath $dotnet).Hash.ToLowerInvariant()
    runtimeDirectory = Join-Path $dotnetRoot $roots.runtime
    groups = $groups
}
# Serialize to a new private path, hash it, and freeze it for the reviewed run.
# Do not copy another machine's binding or refresh it during an attempted run.
```

`helpers/controlled-fixture/Build-ControlledFixture.ps1` takes absolute
`-EvidencePath`, `-ToolchainBindingPath` and its `-ToolchainBindingSha256`.
It requires an existing outer job with kill-on-close, a 3 GiB job memory cap
and no UI restrictions; an unsupervised invocation fails. The invoking
supervisor must also impose 180 seconds, a 3 GiB free-memory floor and
0.5-second sampling. Inspect the build result, both complete capped build
streams, copied source hashes, and the four-file product manifest before use.

Under the separately reviewed native supervisor (240 seconds, 2 GiB family
cap, 3 GiB free floor, 0.5-second sampling), invoke
`Invoke-LaunchBoundNativeControls.ps1 -EvidencePath <fresh-private-directory>
-ProductManifest <absolute-fixture.product.json> -ProductManifestSha256 <hash>`.
`-DiagnosticOnly` limits that invocation to the root-exit diagnostic case.
The complete invocation also requires the four real PowerShell integration
cases. Node IPC controls take positional arguments:
`node tests/Assert-DashboardLaunchBoundNative.js <absolute-pwsh.exe>
<fresh-private-directory> <absolute-fixture.product.json> <hash>`.
Before each native cell, require five free-memory samples spaced at least
500 ms apart, each exceeding 5.25 GiB. Never increase limits to obtain a pass.

The ordered qualification cells are Analyze, FixtureContracts, Protocol,
PSOwner, LegacyPS, Telemetry, Accounting, Diagnostic, Mechanism and NodeIPC.
Analyze includes parser/analyzer checks, offline contracts and a fresh bound
fixture build. Offline cells retain the 180-second/3-GiB limits. A final audit
must bind one coherent source, runtime and product to all ten inner and outer
results, commands, admission samples and complete artifact inventories. Check
every job member and birth identity, exact parent topology, root exclusion,
fanout buffer growth, terminal zero membership, retained-handle exit, both
stream EOF/error states, repeated completion, neighbor survival and retained
unknown-owner profiles. Outer cleanup alone never establishes acceptance.

## Dashboard-only owner publication

`node tests/Assert-DashboardWorkflowPrivacy.js` checks the exact owner/main exception, private admission, unknown-visibility rejection, unchanged daily schedule, dashboard filename allowlist, empty-index staging, deletions and nonregular-file rejection using synthetic temporary Git repositories. PDF publication is excluded.

`./tests/Run-SharedHelperRegression.ps1 -TestName Test-LiveDashboardTenantBinding` extracts only named function definitions from the live wrapper and supplies synthetic Az context/token and CLI mocks. It rejects missing, mismatched or unproven owner tenants and prevents ambient owner fallback while retaining private/local fallback. It performs no sign-in, tenant lookup or live collection and needs no service credentials. A passing source test does not verify the actual configured demo tenant. Do not invoke the live `dry_run` as an offline test; see [the activation binding checklist](../docs/github-actions-setup.md).
